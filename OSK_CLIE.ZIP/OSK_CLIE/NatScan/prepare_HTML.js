oDom=CreateObject("mshtml.HTMLDocument");

infile_name = WScript.Arguments(0);
outfile_name = "Q"+infile_name.substring(0,12); //��१��� ��᫥���� ᨬ���

WScript.Echo(infile_name);

WScript.Echo(outfile_name);
fso =  WScript.CreateObject("Scripting.FileSystemObject");

	outfile = fso.OpenTextFile(outfile_name, 2, true);
	infile = fso.OpenTextFile(infile_name, 1, false);
	while(!infile.AtEndOfStream)
		{	
		line = infile.ReadLine();

		if(line.length > 0)
			{			
			//WScript.Echo(line.length);
			newline=line.replace("border=0","border=1");
                        newline=newline.replace("</u><u>"," ");
                        newline=newline.replace("<sup></sup>"," ");
//                        newline=newline.replace("/<(.*)>.*<\/\1>/
			outfile.WriteLine(newline);
			}	
		}
	infile.Close();
	outfile.Close();
