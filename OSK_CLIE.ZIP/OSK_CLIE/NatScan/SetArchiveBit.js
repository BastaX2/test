infile_name = WScript.Arguments(0);
ToggleArchiveBit(infile_name);

function ToggleArchiveBit(filespec)
{
   var fso, f, r, s;
   fso = new ActiveXObject("Scripting.FileSystemObject");
   f = fso.GetFile(filespec)
   if (f.attributes && 1)
   {
      f.attributes = f.attributes - 1;
      s = "Bit is cleared."+f.attributes;
   }
   else
   {
      f.attributes = f.attributes + 1;
      s =   "Bit is set."+f.attributes;
   }
//   WScript.Echo(s);
   return(s);
}