﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;

namespace rollbase
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            bool isFirstInstance = true;

            Rollbase MF = new Rollbase();
            if (args.Length == 0)
            {
                using (Mutex mtx = new Mutex(true, "Rollbase", out isFirstInstance))
                {
                    if (isFirstInstance)
                    {
                        Application.Run(MF);
                    }
                    else
                    {
                        MessageBox.Show("Приложение уже запущено в одном экземпляре!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            else
            {
                if (args[0].CompareTo("/silent") == 0)
                {
                    if (args.Length < 2)
                    {
                        MessageBox.Show("Не указана база данных, которую необходимо синхронизовать!");
                    }
                    else
                    {
                        TreeView rolls = MF.getTreeNode(false, args[1]);
                        object[] Argument = { rolls, args[1] };
                        DoWorkEventArgs send = new DoWorkEventArgs(Argument);
                        MF.Sync_DoWork(MF, send);
                    }
                    return;
                }
            }
        }
    }
}
