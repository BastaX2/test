﻿using System;
using System.Windows.Forms;

namespace rollbase
{
    public partial class dependForm : Form
    {
        public dependForm()
        {
            InitializeComponent();
        }

        private void ctrlC_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(listRolls.Text.Replace("\n", "\r\n"), TextDataFormat.Text);
            Close();
        }

        private void dependForm_Load(object sender, EventArgs e)
        {

        }
    }
}
