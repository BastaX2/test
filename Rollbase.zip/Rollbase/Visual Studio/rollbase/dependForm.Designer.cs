﻿namespace rollbase
{
    partial class dependForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dependForm));
            this.ctrlC = new System.Windows.Forms.Button();
            this.listRolls = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // ctrlC
            // 
            this.ctrlC.Image = global::rollbase.Properties.Resources.copy;
            this.ctrlC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ctrlC.Location = new System.Drawing.Point(264, 105);
            this.ctrlC.Name = "ctrlC";
            this.ctrlC.Size = new System.Drawing.Size(154, 23);
            this.ctrlC.TabIndex = 0;
            this.ctrlC.Text = "Копировать в буфер";
            this.ctrlC.UseVisualStyleBackColor = true;
            this.ctrlC.Click += new System.EventHandler(this.ctrlC_Click);
            // 
            // listRolls
            // 
            this.listRolls.Dock = System.Windows.Forms.DockStyle.Top;
            this.listRolls.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listRolls.Location = new System.Drawing.Point(0, 0);
            this.listRolls.Name = "listRolls";
            this.listRolls.Size = new System.Drawing.Size(419, 103);
            this.listRolls.TabIndex = 1;
            this.listRolls.Text = "";
            // 
            // dependForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(419, 129);
            this.Controls.Add(this.listRolls);
            this.Controls.Add(this.ctrlC);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "dependForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Зависимости";
            this.Load += new System.EventHandler(this.dependForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ctrlC;
        public System.Windows.Forms.RichTextBox listRolls;
    }
}