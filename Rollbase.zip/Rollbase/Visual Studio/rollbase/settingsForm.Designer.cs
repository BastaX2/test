﻿namespace rollbase
{
    partial class settingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(settingsForm));
            this.MDBFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.rollDir = new System.Windows.Forms.FolderBrowserDialog();
            this.SaveButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.RARFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.generalPage = new System.Windows.Forms.TabPage();
            this.delBase = new System.Windows.Forms.Button();
            this.addNewBase = new System.Windows.Forms.Button();
            this.newBase = new System.Windows.Forms.TextBox();
            this.fromNovo = new System.Windows.Forms.Button();
            this.schemes = new System.Windows.Forms.ListBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.AraLable = new System.Windows.Forms.TextBox();
            this.getAra = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.PickLable = new System.Windows.Forms.TextBox();
            this.getPick = new System.Windows.Forms.Button();
            this.getRAR = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.RARFileLable = new System.Windows.Forms.TextBox();
            this.mdbPage = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.bases = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioS3 = new System.Windows.Forms.RadioButton();
            this.radioD3 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioS2 = new System.Windows.Forms.RadioButton();
            this.radioD2 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioS1 = new System.Windows.Forms.RadioButton();
            this.radioD1 = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dirF3 = new System.Windows.Forms.TextBox();
            this.dirF2 = new System.Windows.Forms.TextBox();
            this.dirF1 = new System.Windows.Forms.TextBox();
            this.mdbFileLable = new System.Windows.Forms.TextBox();
            this.rollDirLable = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.getRollDir = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.getMDB = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.pathPage = new System.Windows.Forms.TabPage();
            this.clearTmpFolder = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tmpPath4 = new System.Windows.Forms.TextBox();
            this.tmpPath3 = new System.Windows.Forms.TextBox();
            this.tmpComp = new System.Windows.Forms.TextBox();
            this.tmpArc = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tmpPath2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tmpPath1 = new System.Windows.Forms.TextBox();
            this.tmpCopy = new System.Windows.Forms.TextBox();
            this.tmpRoll = new System.Windows.Forms.TextBox();
            this.AraFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.PickFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.syncByRun = new System.Windows.Forms.CheckBox();
            this.generalPage.SuspendLayout();
            this.mdbPage.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.pathPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // MDBFileDialog
            // 
            this.MDBFileDialog.Filter = "Microsoft Access|*.mdb";
            this.MDBFileDialog.InitialDirectory = "\".\\\\\"";
            this.MDBFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.MDBFileDialog_FileOk);
            // 
            // SaveButton
            // 
            this.SaveButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.SaveButton.Location = new System.Drawing.Point(459, 161);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(75, 23);
            this.SaveButton.TabIndex = 8;
            this.SaveButton.Text = "Сохранить";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.ExitButton.Location = new System.Drawing.Point(540, 161);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(75, 23);
            this.ExitButton.TabIndex = 9;
            this.ExitButton.Text = "Отменить";
            this.ExitButton.UseVisualStyleBackColor = true;
            // 
            // RARFileDialog
            // 
            this.RARFileDialog.Filter = "Архиватор|*.exe";
            this.RARFileDialog.InitialDirectory = "\".\\\\\"";
            this.RARFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.RARFileDialog_FileOk);
            // 
            // generalPage
            // 
            this.generalPage.Controls.Add(this.syncByRun);
            this.generalPage.Controls.Add(this.delBase);
            this.generalPage.Controls.Add(this.addNewBase);
            this.generalPage.Controls.Add(this.newBase);
            this.generalPage.Controls.Add(this.fromNovo);
            this.generalPage.Controls.Add(this.schemes);
            this.generalPage.Controls.Add(this.label11);
            this.generalPage.Controls.Add(this.label10);
            this.generalPage.Controls.Add(this.AraLable);
            this.generalPage.Controls.Add(this.getAra);
            this.generalPage.Controls.Add(this.label9);
            this.generalPage.Controls.Add(this.PickLable);
            this.generalPage.Controls.Add(this.getPick);
            this.generalPage.Controls.Add(this.getRAR);
            this.generalPage.Controls.Add(this.label8);
            this.generalPage.Controls.Add(this.RARFileLable);
            this.generalPage.Location = new System.Drawing.Point(4, 22);
            this.generalPage.Name = "generalPage";
            this.generalPage.Padding = new System.Windows.Forms.Padding(3);
            this.generalPage.Size = new System.Drawing.Size(619, 185);
            this.generalPage.TabIndex = 1;
            this.generalPage.Text = "Общие настройки";
            this.generalPage.UseVisualStyleBackColor = true;
            // 
            // delBase
            // 
            this.delBase.Image = global::rollbase.Properties.Resources.delete;
            this.delBase.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.delBase.Location = new System.Drawing.Point(282, 153);
            this.delBase.Name = "delBase";
            this.delBase.Size = new System.Drawing.Size(82, 23);
            this.delBase.TabIndex = 46;
            this.delBase.Text = "Удалить";
            this.delBase.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.delBase.UseVisualStyleBackColor = true;
            this.delBase.Click += new System.EventHandler(this.delBase_Click);
            // 
            // addNewBase
            // 
            this.addNewBase.Image = global::rollbase.Properties.Resources.add;
            this.addNewBase.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addNewBase.Location = new System.Drawing.Point(282, 123);
            this.addNewBase.Name = "addNewBase";
            this.addNewBase.Size = new System.Drawing.Size(82, 23);
            this.addNewBase.TabIndex = 45;
            this.addNewBase.Text = "Добавить";
            this.addNewBase.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addNewBase.UseVisualStyleBackColor = true;
            this.addNewBase.Click += new System.EventHandler(this.addNewBase_Click);
            // 
            // newBase
            // 
            this.newBase.Location = new System.Drawing.Point(282, 97);
            this.newBase.Name = "newBase";
            this.newBase.Size = new System.Drawing.Size(154, 20);
            this.newBase.TabIndex = 44;
            // 
            // fromNovo
            // 
            this.fromNovo.Location = new System.Drawing.Point(31, 116);
            this.fromNovo.Name = "fromNovo";
            this.fromNovo.Size = new System.Drawing.Size(118, 23);
            this.fromNovo.TabIndex = 43;
            this.fromNovo.Text = "Заполнить из NOVO";
            this.fromNovo.UseVisualStyleBackColor = true;
            this.fromNovo.Click += new System.EventHandler(this.fromNovo_Click);
            // 
            // schemes
            // 
            this.schemes.Location = new System.Drawing.Point(155, 97);
            this.schemes.Name = "schemes";
            this.schemes.Size = new System.Drawing.Size(120, 82);
            this.schemes.TabIndex = 42;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(27, 100);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(122, 13);
            this.label11.TabIndex = 41;
            this.label11.Text = "Схемы для сравнения:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(36, 71);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(113, 13);
            this.label10.TabIndex = 38;
            this.label10.Text = "Сравнивалка(Merge):";
            // 
            // AraLable
            // 
            this.AraLable.Enabled = false;
            this.AraLable.Location = new System.Drawing.Point(155, 68);
            this.AraLable.Name = "AraLable";
            this.AraLable.Size = new System.Drawing.Size(462, 20);
            this.AraLable.TabIndex = 39;
            // 
            // getAra
            // 
            this.getAra.Location = new System.Drawing.Point(8, 66);
            this.getAra.Name = "getAra";
            this.getAra.Size = new System.Drawing.Size(25, 23);
            this.getAra.TabIndex = 37;
            this.getAra.Text = "...";
            this.getAra.UseVisualStyleBackColor = true;
            this.getAra.Click += new System.EventHandler(this.getAra_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(42, 41);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(107, 13);
            this.label9.TabIndex = 35;
            this.label9.Text = "Менеджер накатов:";
            // 
            // PickLable
            // 
            this.PickLable.Enabled = false;
            this.PickLable.Location = new System.Drawing.Point(155, 38);
            this.PickLable.Name = "PickLable";
            this.PickLable.Size = new System.Drawing.Size(462, 20);
            this.PickLable.TabIndex = 36;
            // 
            // getPick
            // 
            this.getPick.Location = new System.Drawing.Point(8, 36);
            this.getPick.Name = "getPick";
            this.getPick.Size = new System.Drawing.Size(25, 23);
            this.getPick.TabIndex = 34;
            this.getPick.Text = "...";
            this.getPick.UseVisualStyleBackColor = true;
            this.getPick.Click += new System.EventHandler(this.getPick_Click);
            // 
            // getRAR
            // 
            this.getRAR.Location = new System.Drawing.Point(8, 6);
            this.getRAR.Name = "getRAR";
            this.getRAR.Size = new System.Drawing.Size(25, 23);
            this.getRAR.TabIndex = 32;
            this.getRAR.Text = "...";
            this.getRAR.UseVisualStyleBackColor = true;
            this.getRAR.Click += new System.EventHandler(this.getRAR_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(86, 11);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 13);
            this.label8.TabIndex = 31;
            this.label8.Text = "Архиватор:";
            // 
            // RARFileLable
            // 
            this.RARFileLable.Enabled = false;
            this.RARFileLable.Location = new System.Drawing.Point(155, 8);
            this.RARFileLable.Name = "RARFileLable";
            this.RARFileLable.Size = new System.Drawing.Size(462, 20);
            this.RARFileLable.TabIndex = 33;
            // 
            // mdbPage
            // 
            this.mdbPage.Controls.Add(this.label7);
            this.mdbPage.Controls.Add(this.bases);
            this.mdbPage.Controls.Add(this.groupBox3);
            this.mdbPage.Controls.Add(this.groupBox2);
            this.mdbPage.Controls.Add(this.groupBox1);
            this.mdbPage.Controls.Add(this.label6);
            this.mdbPage.Controls.Add(this.label5);
            this.mdbPage.Controls.Add(this.dirF3);
            this.mdbPage.Controls.Add(this.dirF2);
            this.mdbPage.Controls.Add(this.dirF1);
            this.mdbPage.Controls.Add(this.mdbFileLable);
            this.mdbPage.Controls.Add(this.rollDirLable);
            this.mdbPage.Controls.Add(this.label4);
            this.mdbPage.Controls.Add(this.label3);
            this.mdbPage.Controls.Add(this.getRollDir);
            this.mdbPage.Controls.Add(this.label2);
            this.mdbPage.Controls.Add(this.getMDB);
            this.mdbPage.Controls.Add(this.label1);
            this.mdbPage.Location = new System.Drawing.Point(4, 22);
            this.mdbPage.Name = "mdbPage";
            this.mdbPage.Padding = new System.Windows.Forms.Padding(3);
            this.mdbPage.Size = new System.Drawing.Size(619, 185);
            this.mdbPage.TabIndex = 0;
            this.mdbPage.Text = "Базы данных";
            this.mdbPage.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(86, 100);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 37;
            this.label7.Text = "Вид базы:";
            // 
            // bases
            // 
            this.bases.FormattingEnabled = true;
            this.bases.Location = new System.Drawing.Point(23, 116);
            this.bases.Name = "bases";
            this.bases.Size = new System.Drawing.Size(121, 21);
            this.bases.TabIndex = 36;
            this.bases.SelectedValueChanged += new System.EventHandler(this.settingsForm_Load);
            // 
            // groupBox3
            // 
            this.groupBox3.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.groupBox3.AutoSize = true;
            this.groupBox3.Controls.Add(this.radioS3);
            this.groupBox3.Controls.Add(this.radioD3);
            this.groupBox3.Location = new System.Drawing.Point(347, 87);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox3.Size = new System.Drawing.Size(67, 69);
            this.groupBox3.TabIndex = 35;
            this.groupBox3.TabStop = false;
            // 
            // radioS3
            // 
            this.radioS3.AutoSize = true;
            this.radioS3.Location = new System.Drawing.Point(3, 36);
            this.radioS3.Name = "radioS3";
            this.radioS3.Size = new System.Drawing.Size(61, 17);
            this.radioS3.TabIndex = 23;
            this.radioS3.Text = "Строка";
            this.radioS3.UseVisualStyleBackColor = true;
            this.radioS3.CheckedChanged += new System.EventHandler(this.radio_CheckedChanged);
            // 
            // radioD3
            // 
            this.radioD3.AutoSize = true;
            this.radioD3.Location = new System.Drawing.Point(3, 13);
            this.radioD3.Name = "radioD3";
            this.radioD3.Size = new System.Drawing.Size(51, 17);
            this.radioD3.TabIndex = 22;
            this.radioD3.Text = "Дата";
            this.radioD3.UseVisualStyleBackColor = true;
            this.radioD3.CheckedChanged += new System.EventHandler(this.radio_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.groupBox2.AutoSize = true;
            this.groupBox2.Controls.Add(this.radioS2);
            this.groupBox2.Controls.Add(this.radioD2);
            this.groupBox2.Location = new System.Drawing.Point(246, 87);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox2.Size = new System.Drawing.Size(67, 69);
            this.groupBox2.TabIndex = 34;
            this.groupBox2.TabStop = false;
            // 
            // radioS2
            // 
            this.radioS2.AutoSize = true;
            this.radioS2.Location = new System.Drawing.Point(3, 36);
            this.radioS2.Name = "radioS2";
            this.radioS2.Size = new System.Drawing.Size(61, 17);
            this.radioS2.TabIndex = 23;
            this.radioS2.Text = "Строка";
            this.radioS2.UseVisualStyleBackColor = true;
            this.radioS2.CheckedChanged += new System.EventHandler(this.radio_CheckedChanged);
            // 
            // radioD2
            // 
            this.radioD2.AutoSize = true;
            this.radioD2.Location = new System.Drawing.Point(3, 13);
            this.radioD2.Name = "radioD2";
            this.radioD2.Size = new System.Drawing.Size(51, 17);
            this.radioD2.TabIndex = 22;
            this.radioD2.Text = "Дата";
            this.radioD2.UseVisualStyleBackColor = true;
            this.radioD2.CheckedChanged += new System.EventHandler(this.radio_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.groupBox1.AutoSize = true;
            this.groupBox1.Controls.Add(this.radioS1);
            this.groupBox1.Controls.Add(this.radioD1);
            this.groupBox1.Location = new System.Drawing.Point(155, 87);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox1.Size = new System.Drawing.Size(67, 69);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            // 
            // radioS1
            // 
            this.radioS1.AutoSize = true;
            this.radioS1.Location = new System.Drawing.Point(3, 36);
            this.radioS1.Name = "radioS1";
            this.radioS1.Size = new System.Drawing.Size(61, 17);
            this.radioS1.TabIndex = 23;
            this.radioS1.Text = "Строка";
            this.radioS1.UseVisualStyleBackColor = true;
            this.radioS1.CheckedChanged += new System.EventHandler(this.radio_CheckedChanged);
            // 
            // radioD1
            // 
            this.radioD1.AutoSize = true;
            this.radioD1.Location = new System.Drawing.Point(3, 13);
            this.radioD1.Name = "radioD1";
            this.radioD1.Size = new System.Drawing.Size(51, 17);
            this.radioD1.TabIndex = 22;
            this.radioD1.Text = "Дата";
            this.radioD1.UseVisualStyleBackColor = true;
            this.radioD1.CheckedChanged += new System.EventHandler(this.radio_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(410, 67);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 13);
            this.label6.TabIndex = 32;
            this.label6.Text = "\\*\\*.*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(325, 67);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(12, 13);
            this.label5.TabIndex = 30;
            this.label5.Text = "\\";
            // 
            // dirF3
            // 
            this.dirF3.Location = new System.Drawing.Point(343, 64);
            this.dirF3.Name = "dirF3";
            this.dirF3.Size = new System.Drawing.Size(61, 20);
            this.dirF3.TabIndex = 31;
            // 
            // dirF2
            // 
            this.dirF2.Location = new System.Drawing.Point(242, 64);
            this.dirF2.Name = "dirF2";
            this.dirF2.Size = new System.Drawing.Size(77, 20);
            this.dirF2.TabIndex = 29;
            // 
            // dirF1
            // 
            this.dirF1.Location = new System.Drawing.Point(155, 64);
            this.dirF1.Name = "dirF1";
            this.dirF1.Size = new System.Drawing.Size(63, 20);
            this.dirF1.TabIndex = 27;
            // 
            // mdbFileLable
            // 
            this.mdbFileLable.Enabled = false;
            this.mdbFileLable.Location = new System.Drawing.Point(155, 8);
            this.mdbFileLable.Name = "mdbFileLable";
            this.mdbFileLable.Size = new System.Drawing.Size(460, 20);
            this.mdbFileLable.TabIndex = 12;
            // 
            // rollDirLable
            // 
            this.rollDirLable.Location = new System.Drawing.Point(155, 38);
            this.rollDirLable.Name = "rollDirLable";
            this.rollDirLable.Size = new System.Drawing.Size(460, 20);
            this.rollDirLable.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(224, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(12, 13);
            this.label4.TabIndex = 28;
            this.label4.Text = "\\";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(64, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 13);
            this.label3.TabIndex = 26;
            this.label3.Text = "Формат папки:";
            // 
            // getRollDir
            // 
            this.getRollDir.Location = new System.Drawing.Point(8, 36);
            this.getRollDir.Name = "getRollDir";
            this.getRollDir.Size = new System.Drawing.Size(25, 23);
            this.getRollDir.TabIndex = 11;
            this.getRollDir.Text = "...";
            this.getRollDir.UseVisualStyleBackColor = true;
            this.getRollDir.Click += new System.EventHandler(this.getRollDir_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Папка с накатами:";
            // 
            // getMDB
            // 
            this.getMDB.Location = new System.Drawing.Point(8, 6);
            this.getMDB.Name = "getMDB";
            this.getMDB.Size = new System.Drawing.Size(25, 23);
            this.getMDB.TabIndex = 9;
            this.getMDB.Text = "...";
            this.getMDB.UseVisualStyleBackColor = true;
            this.getMDB.Click += new System.EventHandler(this.getMDB_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Файл базы данных:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.mdbPage);
            this.tabControl1.Controls.Add(this.generalPage);
            this.tabControl1.Controls.Add(this.pathPage);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(627, 211);
            this.tabControl1.TabIndex = 31;
            // 
            // pathPage
            // 
            this.pathPage.Controls.Add(this.clearTmpFolder);
            this.pathPage.Controls.Add(this.label15);
            this.pathPage.Controls.Add(this.label14);
            this.pathPage.Controls.Add(this.tmpPath4);
            this.pathPage.Controls.Add(this.tmpPath3);
            this.pathPage.Controls.Add(this.tmpComp);
            this.pathPage.Controls.Add(this.tmpArc);
            this.pathPage.Controls.Add(this.label13);
            this.pathPage.Controls.Add(this.tmpPath2);
            this.pathPage.Controls.Add(this.label12);
            this.pathPage.Controls.Add(this.tmpPath1);
            this.pathPage.Controls.Add(this.tmpCopy);
            this.pathPage.Controls.Add(this.tmpRoll);
            this.pathPage.Location = new System.Drawing.Point(4, 22);
            this.pathPage.Name = "pathPage";
            this.pathPage.Size = new System.Drawing.Size(619, 185);
            this.pathPage.TabIndex = 2;
            this.pathPage.Text = "Настройки путей";
            this.pathPage.UseVisualStyleBackColor = true;
            // 
            // clearTmpFolder
            // 
            this.clearTmpFolder.Location = new System.Drawing.Point(211, 107);
            this.clearTmpFolder.Name = "clearTmpFolder";
            this.clearTmpFolder.Size = new System.Drawing.Size(126, 23);
            this.clearTmpFolder.TabIndex = 6;
            this.clearTmpFolder.Text = "Очистка папок";
            this.clearTmpFolder.UseVisualStyleBackColor = true;
            this.clearTmpFolder.Click += new System.EventHandler(this.clearTmpFolder_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(79, 84);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(126, 13);
            this.label15.TabIndex = 5;
            this.label15.Text = "Директория сравнения";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(73, 58);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(132, 13);
            this.label14.TabIndex = 5;
            this.label14.Text = "Директория распаковки";
            // 
            // tmpPath4
            // 
            this.tmpPath4.Enabled = false;
            this.tmpPath4.Location = new System.Drawing.Point(211, 81);
            this.tmpPath4.Name = "tmpPath4";
            this.tmpPath4.Size = new System.Drawing.Size(294, 20);
            this.tmpPath4.TabIndex = 4;
            this.tmpPath4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tmpPath3
            // 
            this.tmpPath3.Enabled = false;
            this.tmpPath3.Location = new System.Drawing.Point(211, 55);
            this.tmpPath3.Name = "tmpPath3";
            this.tmpPath3.Size = new System.Drawing.Size(294, 20);
            this.tmpPath3.TabIndex = 4;
            this.tmpPath3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tmpComp
            // 
            this.tmpComp.Location = new System.Drawing.Point(511, 81);
            this.tmpComp.Name = "tmpComp";
            this.tmpComp.Size = new System.Drawing.Size(100, 20);
            this.tmpComp.TabIndex = 4;
            // 
            // tmpArc
            // 
            this.tmpArc.Location = new System.Drawing.Point(511, 55);
            this.tmpArc.Name = "tmpArc";
            this.tmpArc.Size = new System.Drawing.Size(100, 20);
            this.tmpArc.TabIndex = 4;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(46, 32);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(159, 13);
            this.label13.TabIndex = 3;
            this.label13.Text = "Директория для копирования";
            // 
            // tmpPath2
            // 
            this.tmpPath2.Enabled = false;
            this.tmpPath2.Location = new System.Drawing.Point(211, 29);
            this.tmpPath2.Name = "tmpPath2";
            this.tmpPath2.Size = new System.Drawing.Size(294, 20);
            this.tmpPath2.TabIndex = 1;
            this.tmpPath2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(5, 6);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(200, 13);
            this.label12.TabIndex = 2;
            this.label12.Text = "Распаковка для добавления в дерево";
            // 
            // tmpPath1
            // 
            this.tmpPath1.Enabled = false;
            this.tmpPath1.Location = new System.Drawing.Point(211, 3);
            this.tmpPath1.Name = "tmpPath1";
            this.tmpPath1.Size = new System.Drawing.Size(294, 20);
            this.tmpPath1.TabIndex = 0;
            this.tmpPath1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tmpCopy
            // 
            this.tmpCopy.Location = new System.Drawing.Point(511, 29);
            this.tmpCopy.Name = "tmpCopy";
            this.tmpCopy.Size = new System.Drawing.Size(100, 20);
            this.tmpCopy.TabIndex = 1;
            // 
            // tmpRoll
            // 
            this.tmpRoll.Location = new System.Drawing.Point(511, 3);
            this.tmpRoll.Name = "tmpRoll";
            this.tmpRoll.Size = new System.Drawing.Size(100, 20);
            this.tmpRoll.TabIndex = 0;
            // 
            // AraFileDialog
            // 
            this.AraFileDialog.Filter = "Merge Apllication|*.exe|Araxis Merge|merge.exe|WinMerge|winmergeu.exe|KDiff3|kdif" +
    "f3.exe";
            this.AraFileDialog.InitialDirectory = "\".\\\\\"";
            this.AraFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.AraFileDialog_FileOk);
            // 
            // PickFileDialog
            // 
            this.PickFileDialog.Filter = "Администратор проектов|Pick*.exe";
            this.PickFileDialog.InitialDirectory = "\".\\\\\"";
            this.PickFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.PickFileDialog_FileOk);
            // 
            // syncByRun
            // 
            this.syncByRun.AutoSize = true;
            this.syncByRun.Location = new System.Drawing.Point(7, 146);
            this.syncByRun.Name = "syncByRun";
            this.syncByRun.Size = new System.Drawing.Size(142, 30);
            this.syncByRun.TabIndex = 47;
            this.syncByRun.Text = "Синхронизировать при\r\nзапуске приложения";
            this.syncByRun.UseVisualStyleBackColor = true;
            // 
            // settingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(627, 211);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "settingsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Наcтройки";
            this.Load += new System.EventHandler(this.settingsForm_Load);
            this.generalPage.ResumeLayout(false);
            this.generalPage.PerformLayout();
            this.mdbPage.ResumeLayout(false);
            this.mdbPage.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.pathPage.ResumeLayout(false);
            this.pathPage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog MDBFileDialog;
        private System.Windows.Forms.FolderBrowserDialog rollDir;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.OpenFileDialog RARFileDialog;
        private System.Windows.Forms.TabPage generalPage;
        private System.Windows.Forms.Button getRAR;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox RARFileLable;
        private System.Windows.Forms.TabPage mdbPage;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.ComboBox bases;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioS3;
        private System.Windows.Forms.RadioButton radioD3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioS2;
        private System.Windows.Forms.RadioButton radioD2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioS1;
        private System.Windows.Forms.RadioButton radioD1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox dirF3;
        private System.Windows.Forms.TextBox dirF2;
        private System.Windows.Forms.TextBox dirF1;
        private System.Windows.Forms.TextBox mdbFileLable;
        private System.Windows.Forms.TextBox rollDirLable;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button getRollDir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button getMDB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Button getPick;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox PickLable;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox AraLable;
        private System.Windows.Forms.Button getAra;
        private System.Windows.Forms.OpenFileDialog AraFileDialog;
        private System.Windows.Forms.OpenFileDialog PickFileDialog;
        private System.Windows.Forms.ListBox schemes;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button addNewBase;
        private System.Windows.Forms.TextBox newBase;
        private System.Windows.Forms.Button fromNovo;
        private System.Windows.Forms.Button delBase;
        private System.Windows.Forms.TabPage pathPage;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tmpCopy;
        private System.Windows.Forms.TextBox tmpRoll;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tmpArc;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tmpComp;
        private System.Windows.Forms.TextBox tmpPath4;
        private System.Windows.Forms.TextBox tmpPath3;
        private System.Windows.Forms.TextBox tmpPath2;
        private System.Windows.Forms.TextBox tmpPath1;
        private System.Windows.Forms.Button clearTmpFolder;
        private System.Windows.Forms.CheckBox syncByRun;
    }
}