﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Data.OleDb;
using System.IO;


namespace rollbase
{
    public partial class settingsForm : Form
    {
        private Form logicalParent;

        public settingsForm(Form parent)
        {
            InitializeComponent();
            logicalParent = parent;
        }

        private char[] charsToTrim = { '\\', ' ' };
        private void settingsForm_Load(object sender, EventArgs e)
        {
            RegistryKey RegKey;
            string tmpstr;
            RegKey = Registry.CurrentUser.OpenSubKey(rollbase.Properties.Resources.regKeyName);
            if (bases.Items.Count == 0)
            {
                string[] listbases = (string[])RegKey.GetValue("Bases", new string[] { (string)RegKey.GetValue("defBase", "RTL") });
                bases.Items.AddRange(listbases);
                if (((Rollbase)logicalParent).selBase.SelectedItem != null)
                    bases.Text = ((Rollbase)logicalParent).selBase.SelectedItem.ToString();
                else
                    radioS1.Checked = radioS2.Checked = radioS3.Checked = true;
            }
            else
            {
                RARFileLable.Text = (string)RegKey.GetValue("Archiver", "winrar.exe");
                AraLable.Text = (string)RegKey.GetValue("Merge", "merge.exe");
                PickLable.Text = (string)RegKey.GetValue("Pick", "Pick.exe");
                schemes.Items.AddRange((string[])RegKey.GetValue("Schemes", new string[] { }));
                syncByRun.Checked = Convert.ToBoolean(RegKey.GetValue("SyncByRun", 0));

                tmpPath1.Text = tmpPath2.Text = tmpPath3.Text = tmpPath4.Text = Path.GetTempPath() + "tmpRollBase\\";
                tmpRoll.Text = RegKey.GetValue("tmpRoll", "dbFill").ToString().Replace(tmpPath1.Text, "").TrimEnd(charsToTrim);
                tmpCopy.Text = RegKey.GetValue("tmpCopy", "Copy").ToString().Replace(tmpPath2.Text, "").TrimEnd(charsToTrim);
                tmpArc.Text = RegKey.GetValue("tmpArc", "Exctract").ToString().Replace(tmpPath3.Text, "").TrimEnd(charsToTrim);
                tmpComp.Text = RegKey.GetValue("tmpComp", "Compare").ToString().Replace(tmpPath4.Text, "").TrimEnd(charsToTrim);

                RegKey.Close();

                RegKey = Registry.CurrentUser.OpenSubKey(rollbase.Properties.Resources.regKeyName + @"\" + bases.Text.ToString());
                if (RegKey == null)
                {
                    RegKey = Registry.CurrentUser.CreateSubKey(rollbase.Properties.Resources.regKeyName + @"\" + bases.Text.ToString());
                }

                mdbFileLable.Text = (string)RegKey.GetValue("mdbPath", "rollbase_" + bases.Text + ".mdb");
                rollDirLable.Text = (string)RegKey.GetValue("rollDir", System.Environment.SpecialFolder.Desktop.ToString());

                tmpstr = (string)RegKey.GetValue("dirF1", "*");
                if (tmpstr == "*")
                {
                    radioS1.Checked = true;
                }
                else
                {
                    radioD1.Checked = true;
                }
                dirF1.Text = tmpstr;

                tmpstr = (string)RegKey.GetValue("dirF2", "*");
                if (tmpstr == "*")
                {
                    radioS2.Checked = true;
                }
                else
                {
                    radioD2.Checked = true;

                }
                dirF2.Text = tmpstr;

                tmpstr = (string)RegKey.GetValue("dirF3", "*");
                if (tmpstr == "*")
                {
                    radioS3.Checked = true;
                }
                else
                {
                    radioD3.Checked = true;
                }
                dirF3.Text = tmpstr;
            }
            RegKey.Close();
        }

        private void getMDB_Click(object sender, EventArgs e)
        {
            MDBFileDialog.ShowDialog();
        }

        private void MDBFileDialog_FileOk(object sender, CancelEventArgs e)
        {
            mdbFileLable.Text = MDBFileDialog.FileName;
            string conn_string = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" + mdbFileLable.Text + "; User ID = Admin; Password =;";
            OleDbConnection conn = new OleDbConnection(conn_string);
            try
            {
                conn.Open();
                string sql = "select name, valstr from settings";
                string param;
                OleDbCommand cmd = new OleDbCommand(sql, conn);
                OleDbDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (reader.IsDBNull(0))
                        continue;
                    
                    if (reader.IsDBNull(1))
                    {
                        param = "*";
                    }
                    else
                    {
                        param = reader.GetString(1);
                    }

                    switch (reader.GetString(0))
                    {
                        case "rolldir":
                            rollDirLable.Text = param;
                            break;
                        case "yearfolderformat":
                            if (param == "*")
                                radioS1.Checked = true;
                            else
                            {
                                radioD1.Checked = true;
                                dirF1.Text = param;
                            }
                            break;
                        case "monthfolderformat":
                            if (param == "*")
                                radioS2.Checked = true;
                            else
                            {
                                radioD2.Checked = true;
                                dirF2.Text = param;
                            }
                            break;
                        case "dayfolderformat":
                            if (param == "*")
                                radioS3.Checked = true;
                            else
                            {
                                radioD3.Checked = true;
                                dirF3.Text = param;
                            }
                            break;
                        default:
                            break;
                    }
                }
                reader.Close();
                cmd.Dispose();
                conn.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Невозможно подключиьтся к БД или загрузить настройки " + ex.Message);
            }

        }

        private void getRollDir_Click(object sender, EventArgs e)
        {
            rollDir.ShowDialog();
            rollDirLable.Text = rollDir.SelectedPath;
        }

        private void rollDirLable_TextChanged(object sender, EventArgs e)
        {
            rollDir.SelectedPath = rollDirLable.Text;
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            string[] allBases;
            bool newBase = true;
            RegistryKey RegKey;
            string[] shm = new string[schemes.Items.Count];

            for(int i = 0; i < schemes.Items.Count; i++)
            {
                shm[i] = schemes.Items[i].ToString();
            }

            allBases = new string[bases.Items.Count + 1];

            for (int i = 0; i < bases.Items.Count; i++)
            {
                allBases[i] = bases.GetItemText(bases.Items[i]);
                if (allBases[i].CompareTo(bases.Text) == 0)
                {
                    newBase = false;
                    break;
                }
            }

            RegKey = Registry.CurrentUser.OpenSubKey(rollbase.Properties.Resources.regKeyName, true);
            RegKey.SetValue("DefBase", bases.Text, RegistryValueKind.String);

            RegKey.SetValue("Archiver", RARFileLable.Text, RegistryValueKind.String);
            RegKey.SetValue("Merge", AraLable.Text, RegistryValueKind.String);
            RegKey.SetValue("Pick", PickLable.Text, RegistryValueKind.String);
            RegKey.SetValue("Schemes", shm, RegistryValueKind.MultiString);
            RegKey.SetValue("SyncByRun", syncByRun.Checked, RegistryValueKind.DWord);


            RegKey.SetValue("tmpRoll", tmpPath1.Text + tmpRoll.Text.TrimEnd(charsToTrim) + "\\", RegistryValueKind.String);
            RegKey.SetValue("tmpCopy", tmpPath2.Text + tmpCopy.Text.TrimEnd(charsToTrim) + "\\", RegistryValueKind.String);
            RegKey.SetValue("tmpArc", tmpPath3.Text + tmpArc.Text.TrimEnd(charsToTrim) + "\\", RegistryValueKind.String);
            RegKey.SetValue("tmpComp", tmpPath4.Text + tmpComp.Text.TrimEnd(charsToTrim) + "\\", RegistryValueKind.String);


            if (newBase == true)
            {
                allBases[bases.Items.Count] = bases.Text;
                RegKey.SetValue("Bases", allBases, RegistryValueKind.MultiString);
            }
            else
            {
                ((Rollbase)logicalParent).selBase.Items.Clear();
                ((Rollbase)logicalParent).selBase.SelectedItem = bases.Text;
            }
            RegKey.Close();

            if (string.IsNullOrEmpty(mdbFileLable.Text))
            {
                mdbFileLable.Text = "rollbase_" + bases.Text + ".mdb";
            }
            RegKey = Registry.CurrentUser.OpenSubKey(rollbase.Properties.Resources.regKeyName + @"\" + bases.Text, true);
            if (RegKey == null)
            {
                RegKey = Registry.CurrentUser.CreateSubKey(rollbase.Properties.Resources.regKeyName + @"\" + bases.Text);
            }
            RegKey.SetValue("mdbPath", mdbFileLable.Text, RegistryValueKind.String);
            RegKey.SetValue("rollDir", rollDirLable.Text, RegistryValueKind.String);
            RegKey.SetValue("dirF1", dirF1.Text, RegistryValueKind.String);
            RegKey.SetValue("dirF2", dirF2.Text, RegistryValueKind.String);
            RegKey.SetValue("dirF3", dirF3.Text, RegistryValueKind.String);
            RegKey.Close();

            try
            {
                string conn_string = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" + mdbFileLable.Text + "; User ID = Admin; Password =;";
                OleDbConnection conn = new OleDbConnection(conn_string);
                OleDbCommand cmd;
                string upd_rolldir = "update settings set valstr = \"" + rollDirLable.Text + "\" where name=\"rolldir\"";
                string upd_dirF1 = "update settings set valstr = \"" + dirF1.Text + "\" where name=\"yearfolderformat\"";
                string upd_dirF2 = "update settings set valstr = \"" + dirF2.Text + "\" where name=\"monthfolderformat\"";
                string upd_dirF3 = "update settings set valstr = \"" + dirF3.Text + "\" where name=\"dayfolderformat\"";

                conn.Open();
                cmd = new OleDbCommand(upd_rolldir, conn);
                cmd.ExecuteNonQuery();
                cmd.CommandText = upd_dirF1;
                cmd.ExecuteNonQuery();
                cmd.CommandText = upd_dirF2;
                cmd.ExecuteNonQuery();
                cmd.CommandText = upd_dirF3;
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Натройки не были сохранены в БД. " + ex.Message);
            }

        }

        private void getRAR_Click(object sender, EventArgs e)
        {
            RARFileDialog.ShowDialog();
        }

        private void RARFileDialog_FileOk(object sender, CancelEventArgs e)
        {
            RARFileLable.Text = RARFileDialog.FileName;
        }

        private void getAra_Click(object sender, EventArgs e)
        {
            AraFileDialog.ShowDialog();
        }

        private void getPick_Click(object sender, EventArgs e)
        {
            PickFileDialog.ShowDialog();
        }

        private void AraFileDialog_FileOk(object sender, CancelEventArgs e)
        {
            AraLable.Text = AraFileDialog.FileName;
        }

        private void PickFileDialog_FileOk(object sender, CancelEventArgs e)
        {
            PickLable.Text = PickFileDialog.FileName;
        }

        private void add_new_scheme(string newBase)
        {
            bool fl = false;

            newBase = newBase.ToUpper();
            foreach (string scheme in schemes.Items)
            {
                if (scheme.ToUpper().CompareTo(newBase.ToUpper()) == 0)
                {
                    fl = true;
                    break;
                }
            }
            if (fl == false)
            {
                schemes.Items.Add(newBase);
            }
        }

        private void fromNovo_Click(object sender, EventArgs e)
        {
            RegistryKey RegKey = Registry.CurrentUser.OpenSubKey("Software\\FTC\\IBS\\Profiles", false);
            foreach(string bases in RegKey.GetSubKeyNames())
            {
                add_new_scheme(bases);
            }
        }

        private void addNewBase_Click(object sender, EventArgs e)
        {
            add_new_scheme(newBase.Text);
            newBase.Text = "";
        }

        private void delBase_Click(object sender, EventArgs e)
        {
            schemes.Items.Remove(schemes.SelectedItem);
        }

        private void clearTmpFolder_Click(object sender, EventArgs e)
        {
            try
            {
                Directory.CreateDirectory(tmpPath1.Text + tmpRoll.Text.TrimEnd(charsToTrim));
                Directory.Delete(tmpPath1.Text + tmpRoll.Text.TrimEnd(charsToTrim), true);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Во время очиcтки произошла ошибка: " + ex.Message);
            }

            try
            {
                Directory.CreateDirectory(tmpPath2.Text + tmpCopy.Text.TrimEnd(charsToTrim));
                Directory.Delete(tmpPath2.Text + tmpCopy.Text.TrimEnd(charsToTrim), true);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Во время очиcтки произошла ошибка: " + ex.Message);
            }

            try
            {
                Directory.CreateDirectory(tmpPath3.Text + tmpArc.Text.TrimEnd(charsToTrim));
                Directory.Delete(tmpPath3.Text + tmpArc.Text.TrimEnd(charsToTrim), true);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Во время очиcтки произошла ошибка: " + ex.Message);
            }

            try
            {
                Directory.CreateDirectory(tmpPath4.Text + tmpComp.Text.TrimEnd(charsToTrim));
                Directory.Delete(tmpPath4.Text + tmpComp.Text.TrimEnd(charsToTrim), true);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Во время очиcтки произошла ошибка: " + ex.Message);
            }
            MessageBox.Show("Очистка окончена!");
        }

        private void radio_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = (RadioButton)sender;
            if (rb.Checked == true)
            {
                switch(rb.Name)
                {
                    case "radioS1":
                        dirF1.Enabled = false;
                        dirF1.Text = "*";
                        break;
                    case "radioS2":
                        dirF2.Enabled = false;
                        dirF2.Text = "*";
                        break;
                    case "radioS3":
                        dirF3.Enabled = false;
                        dirF3.Text = "*";
                        break;
                    case "radioD1":
                        dirF2.Enabled = true;
                        dirF2.Text = "yyyy";
                        break;
                    case "radioD2":
                        dirF2.Enabled = true;
                        dirF2.Text = "yyyyMMdd";
                        break;
                    case "radioD3":
                        dirF3.Enabled = true;
                        dirF3.Text = "dd";
                        break;
                }

            }
        }
    }
}
