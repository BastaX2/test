﻿using System;
using System.Windows.Forms;
using Microsoft.Win32;


namespace rollbase
{
    public partial class compareForm : Form
    {
        public string scheme2config;
        public string usr2config;

        public compareForm()
        {
            InitializeComponent();
        }

        private void compareForm_Load(object sender, EventArgs e)
        {
            RegistryKey RegKey = Registry.CurrentUser.OpenSubKey(rollbase.Properties.Resources.regKeyName);
            string Pick = (string)RegKey.GetValue("Pick", null);
            string Merge = (string)RegKey.GetValue("Merge", null);

            schemes.Items.AddRange((string[])RegKey.GetValue("Schemes", new string[] { }));
            schemes.SelectedItem = (string)RegKey.GetValue("DefSchemes", "");

            RegKey.Close();

            if (Pick == null)
            {
                picked.Enabled = false;
                merged.Enabled = false;
            }
            else
            {
                picked.Checked = true;
            }

            if(Merge == null)
            {
                merged.Enabled = false;
            }
            else
            {
                merged.Checked = true;
            }

            
        }

        private void Exec_Click(object sender, EventArgs e)
        {
            RegistryKey RegKey = Registry.CurrentUser.OpenSubKey(rollbase.Properties.Resources.regKeyName, true);
            RegKey.SetValue("DefSchemes", schemes.SelectedItem.ToString(), RegistryValueKind.String);
            RegKey.Close();
            scheme2config = schemes.SelectedItem.ToString();
            usr2config = usrBase.Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pwdBase.Text = "";
        }

        private void pwdBase_DragEnter(object sender, DragEventArgs e)
        {
            Exec_Click(sender, e);
        }

        private void compareForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Exec_Click(sender, e);
                this.DialogResult = DialogResult.OK;
            }
        }
    }
}
