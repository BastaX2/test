﻿namespace rollbase
{
    partial class compareForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(compareForm));
            this.roll2compare = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.picked = new System.Windows.Forms.CheckBox();
            this.merged = new System.Windows.Forms.CheckBox();
            this.Exec = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pwdBase = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.usrBase = new System.Windows.Forms.TextBox();
            this.schemes = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // roll2compare
            // 
            this.roll2compare.Location = new System.Drawing.Point(88, 6);
            this.roll2compare.Name = "roll2compare";
            this.roll2compare.Size = new System.Drawing.Size(335, 20);
            this.roll2compare.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Имя наката:";
            // 
            // picked
            // 
            this.picked.AutoSize = true;
            this.picked.Location = new System.Drawing.Point(217, 32);
            this.picked.Name = "picked";
            this.picked.Size = new System.Drawing.Size(206, 17);
            this.picked.TabIndex = 5;
            this.picked.Text = "Создать текстовое представление:";
            this.picked.UseVisualStyleBackColor = true;
            // 
            // merged
            // 
            this.merged.AutoSize = true;
            this.merged.Location = new System.Drawing.Point(217, 55);
            this.merged.Name = "merged";
            this.merged.Size = new System.Drawing.Size(127, 17);
            this.merged.TabIndex = 6;
            this.merged.Text = "Открыть сравнение";
            this.merged.UseVisualStyleBackColor = true;
            // 
            // Exec
            // 
            this.Exec.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Exec.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Exec.Location = new System.Drawing.Point(250, 83);
            this.Exec.Name = "Exec";
            this.Exec.Size = new System.Drawing.Size(75, 23);
            this.Exec.TabIndex = 7;
            this.Exec.Text = "Выполнить";
            this.Exec.UseVisualStyleBackColor = true;
            this.Exec.Click += new System.EventHandler(this.Exec_Click);
            // 
            // button2
            // 
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(331, 83);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 8;
            this.button2.Text = "Закрыть";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pwdBase
            // 
            this.pwdBase.Location = new System.Drawing.Point(66, 85);
            this.pwdBase.Name = "pwdBase";
            this.pwdBase.PasswordChar = '*';
            this.pwdBase.Size = new System.Drawing.Size(130, 20);
            this.pwdBase.TabIndex = 0;
            this.pwdBase.KeyDown += new System.Windows.Forms.KeyEventHandler(this.compareForm_KeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Пароль:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Пользователь:";
            // 
            // usrBase
            // 
            this.usrBase.Location = new System.Drawing.Point(101, 59);
            this.usrBase.Name = "usrBase";
            this.usrBase.Size = new System.Drawing.Size(95, 20);
            this.usrBase.TabIndex = 3;
            this.usrBase.Text = "IBS";
            // 
            // schemes
            // 
            this.schemes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.schemes.FormattingEnabled = true;
            this.schemes.Location = new System.Drawing.Point(60, 32);
            this.schemes.Name = "schemes";
            this.schemes.Size = new System.Drawing.Size(136, 21);
            this.schemes.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Схема:";
            // 
            // compareForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 110);
            this.Controls.Add(this.schemes);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.usrBase);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pwdBase);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Exec);
            this.Controls.Add(this.merged);
            this.Controls.Add(this.picked);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.roll2compare);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "compareForm";
            this.Text = "Выполнить сравнение";
            this.Load += new System.EventHandler(this.compareForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.compareForm_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Exec;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox usrBase;
        private System.Windows.Forms.ComboBox schemes;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox roll2compare;
        public System.Windows.Forms.TextBox pwdBase;
        public System.Windows.Forms.CheckBox picked;
        public System.Windows.Forms.CheckBox merged;
    }
}