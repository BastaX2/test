﻿namespace rollbase
{
    partial class Rollbase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rollbase));
            this.mainMenu = new System.Windows.Forms.MenuStrip();
            this.настройкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.синхронизацияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.зависимостиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selBase = new System.Windows.Forms.ToolStripComboBox();
            this.обновитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.режимОжиданияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.StatusSync = new System.Windows.Forms.StatusStrip();
            this.ProgressSync = new System.Windows.Forms.ToolStripProgressBar();
            this.SyncProcent = new System.Windows.Forms.ToolStripStatusLabel();
            this.CancelSync = new System.Windows.Forms.ToolStripStatusLabel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.FilterCheck = new System.Windows.Forms.CheckBox();
            this.rollFilter = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.fileFilter = new System.Windows.Forms.TextBox();
            this.Filter = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtFilter = new System.Windows.Forms.TextBox();
            this.pckFilter = new System.Windows.Forms.TextBox();
            this.rolls = new System.Windows.Forms.TreeView();
            this.treeMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.развернутьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.свернутьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.копироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.извлечьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.создатьСравнениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.копироватьПутьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.label2 = new System.Windows.Forms.Label();
            this.pck = new System.Windows.Forms.RichTextBox();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.files = new System.Windows.Forms.ListBox();
            this.readme = new System.Windows.Forms.RichTextBox();
            this.openPCK = new System.Windows.Forms.OpenFileDialog();
            this.Sync = new System.ComponentModel.BackgroundWorker();
            this.NotifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.NotifyMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.востановитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Watcher = new System.IO.FileSystemWatcher();
            this.mainMenu.SuspendLayout();
            this.toolStripContainer1.BottomToolStripPanel.SuspendLayout();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.StatusSync.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).BeginInit();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            this.treeMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            this.NotifyMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Watcher)).BeginInit();
            this.SuspendLayout();
            // 
            // mainMenu
            // 
            this.mainMenu.AllowDrop = true;
            this.mainMenu.AllowMerge = false;
            this.mainMenu.Dock = System.Windows.Forms.DockStyle.None;
            this.mainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.настройкиToolStripMenuItem,
            this.синхронизацияToolStripMenuItem,
            this.зависимостиToolStripMenuItem,
            this.selBase,
            this.обновитьToolStripMenuItem,
            this.toolStripMenuItem2,
            this.оПрограммеToolStripMenuItem,
            this.режимОжиданияToolStripMenuItem});
            this.mainMenu.Location = new System.Drawing.Point(0, 0);
            this.mainMenu.MinimumSize = new System.Drawing.Size(2, 24);
            this.mainMenu.Name = "mainMenu";
            this.mainMenu.Size = new System.Drawing.Size(784, 27);
            this.mainMenu.TabIndex = 1;
            this.mainMenu.Text = "menuStrip1";
            // 
            // настройкиToolStripMenuItem
            // 
            this.настройкиToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("настройкиToolStripMenuItem.Image")));
            this.настройкиToolStripMenuItem.Name = "настройкиToolStripMenuItem";
            this.настройкиToolStripMenuItem.Size = new System.Drawing.Size(95, 23);
            this.настройкиToolStripMenuItem.Text = "Настройки";
            this.настройкиToolStripMenuItem.Click += new System.EventHandler(this.настройкиToolStripMenuItem_Click);
            // 
            // синхронизацияToolStripMenuItem
            // 
            this.синхронизацияToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("синхронизацияToolStripMenuItem.Image")));
            this.синхронизацияToolStripMenuItem.Name = "синхронизацияToolStripMenuItem";
            this.синхронизацияToolStripMenuItem.Size = new System.Drawing.Size(121, 23);
            this.синхронизацияToolStripMenuItem.Text = "Cинхронизация";
            this.синхронизацияToolStripMenuItem.Click += new System.EventHandler(this.синхронизацияToolStripMenuItem_Click);
            // 
            // зависимостиToolStripMenuItem
            // 
            this.зависимостиToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("зависимостиToolStripMenuItem.Image")));
            this.зависимостиToolStripMenuItem.Name = "зависимостиToolStripMenuItem";
            this.зависимостиToolStripMenuItem.Size = new System.Drawing.Size(108, 23);
            this.зависимостиToolStripMenuItem.Text = "Зависимости";
            this.зависимостиToolStripMenuItem.Click += new System.EventHandler(this.зависимостиToolStripMenuItem_Click);
            // 
            // selBase
            // 
            this.selBase.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selBase.Name = "selBase";
            this.selBase.Size = new System.Drawing.Size(121, 23);
            this.selBase.SelectedIndexChanged += new System.EventHandler(this.selBase_SelectedIndexChanged);
            // 
            // обновитьToolStripMenuItem
            // 
            this.обновитьToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("обновитьToolStripMenuItem.Image")));
            this.обновитьToolStripMenuItem.Name = "обновитьToolStripMenuItem";
            this.обновитьToolStripMenuItem.Size = new System.Drawing.Size(28, 23);
            this.обновитьToolStripMenuItem.Click += new System.EventHandler(this.обновитьToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(12, 23);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Image = global::rollbase.Properties.Resources.green;
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(110, 23);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // режимОжиданияToolStripMenuItem
            // 
            this.режимОжиданияToolStripMenuItem.Image = global::rollbase.Properties.Resources.timerefresh;
            this.режимОжиданияToolStripMenuItem.Name = "режимОжиданияToolStripMenuItem";
            this.режимОжиданияToolStripMenuItem.Size = new System.Drawing.Size(131, 23);
            this.режимОжиданияToolStripMenuItem.Text = "Режим ожидания";
            this.режимОжиданияToolStripMenuItem.Click += new System.EventHandler(this.режимОжиданияToolStripMenuItem_Click);
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.BottomToolStripPanel
            // 
            this.toolStripContainer1.BottomToolStripPanel.Controls.Add(this.StatusSync);
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.splitContainer1);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(784, 513);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(784, 562);
            this.toolStripContainer1.TabIndex = 3;
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.mainMenu);
            // 
            // StatusSync
            // 
            this.StatusSync.Dock = System.Windows.Forms.DockStyle.None;
            this.StatusSync.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ProgressSync,
            this.SyncProcent,
            this.CancelSync});
            this.StatusSync.Location = new System.Drawing.Point(0, 0);
            this.StatusSync.Name = "StatusSync";
            this.StatusSync.Size = new System.Drawing.Size(784, 22);
            this.StatusSync.TabIndex = 11;
            this.StatusSync.Text = "statusStrip1";
            // 
            // ProgressSync
            // 
            this.ProgressSync.Name = "ProgressSync";
            this.ProgressSync.Size = new System.Drawing.Size(100, 16);
            // 
            // SyncProcent
            // 
            this.SyncProcent.Name = "SyncProcent";
            this.SyncProcent.Size = new System.Drawing.Size(0, 17);
            // 
            // CancelSync
            // 
            this.CancelSync.Image = ((System.Drawing.Image)(resources.GetObject("CancelSync.Image")));
            this.CancelSync.Name = "CancelSync";
            this.CancelSync.Size = new System.Drawing.Size(16, 17);
            this.CancelSync.Visible = false;
            this.CancelSync.Click += new System.EventHandler(this.CancelSync_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            this.splitContainer1.Panel1MinSize = 230;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer1.Panel2.Cursor = System.Windows.Forms.Cursors.Default;
            this.splitContainer1.Size = new System.Drawing.Size(784, 513);
            this.splitContainer1.SplitterDistance = 230;
            this.splitContainer1.TabIndex = 3;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer7);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.rolls);
            this.splitContainer2.Size = new System.Drawing.Size(230, 513);
            this.splitContainer2.SplitterDistance = 160;
            this.splitContainer2.TabIndex = 5;
            // 
            // splitContainer7
            // 
            this.splitContainer7.Cursor = System.Windows.Forms.Cursors.Default;
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer7.IsSplitterFixed = true;
            this.splitContainer7.Location = new System.Drawing.Point(0, 0);
            this.splitContainer7.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainer7.Name = "splitContainer7";
            this.splitContainer7.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.FilterCheck);
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.rollFilter);
            this.splitContainer7.Panel2.Controls.Add(this.label6);
            this.splitContainer7.Panel2.Controls.Add(this.fileFilter);
            this.splitContainer7.Panel2.Controls.Add(this.Filter);
            this.splitContainer7.Panel2.Controls.Add(this.label5);
            this.splitContainer7.Panel2.Controls.Add(this.label4);
            this.splitContainer7.Panel2.Controls.Add(this.label3);
            this.splitContainer7.Panel2.Controls.Add(this.txtFilter);
            this.splitContainer7.Panel2.Controls.Add(this.pckFilter);
            this.splitContainer7.Panel2MinSize = 0;
            this.splitContainer7.Size = new System.Drawing.Size(230, 160);
            this.splitContainer7.SplitterDistance = 25;
            this.splitContainer7.SplitterWidth = 1;
            this.splitContainer7.TabIndex = 7;
            // 
            // FilterCheck
            // 
            this.FilterCheck.Appearance = System.Windows.Forms.Appearance.Button;
            this.FilterCheck.AutoSize = true;
            this.FilterCheck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FilterCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FilterCheck.Location = new System.Drawing.Point(0, 0);
            this.FilterCheck.Name = "FilterCheck";
            this.FilterCheck.Size = new System.Drawing.Size(230, 25);
            this.FilterCheck.TabIndex = 9;
            this.FilterCheck.Text = "Фильтр";
            this.FilterCheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.FilterCheck.UseVisualStyleBackColor = true;
            this.FilterCheck.CheckedChanged += new System.EventHandler(this.TreeFilter_SelectedIndexChanged);
            // 
            // rollFilter
            // 
            this.rollFilter.Location = new System.Drawing.Point(87, 81);
            this.rollFilter.Name = "rollFilter";
            this.rollFilter.Size = new System.Drawing.Size(141, 20);
            this.rollFilter.TabIndex = 3;
            this.rollFilter.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Filter_KeyDown);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label6.Location = new System.Drawing.Point(-7, 80);
            this.label6.MinimumSize = new System.Drawing.Size(53, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "Имя наката:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // fileFilter
            // 
            this.fileFilter.Location = new System.Drawing.Point(87, 55);
            this.fileFilter.Name = "fileFilter";
            this.fileFilter.Size = new System.Drawing.Size(141, 20);
            this.fileFilter.TabIndex = 2;
            this.fileFilter.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Filter_KeyDown);
            // 
            // Filter
            // 
            this.Filter.Location = new System.Drawing.Point(4, 107);
            this.Filter.Name = "Filter";
            this.Filter.Size = new System.Drawing.Size(224, 23);
            this.Filter.TabIndex = 4;
            this.Filter.Text = "Применить фильтр";
            this.Filter.UseVisualStyleBackColor = true;
            this.Filter.Click += new System.EventHandler(this.Filter_Click);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label5.Location = new System.Drawing.Point(-7, 54);
            this.label5.MinimumSize = new System.Drawing.Size(53, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Имя файла:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label4.Location = new System.Drawing.Point(12, 30);
            this.label4.MinimumSize = new System.Drawing.Size(53, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Описание:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label3.Location = new System.Drawing.Point(28, 4);
            this.label3.MinimumSize = new System.Drawing.Size(53, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "PCK:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtFilter
            // 
            this.txtFilter.Location = new System.Drawing.Point(87, 29);
            this.txtFilter.Name = "txtFilter";
            this.txtFilter.Size = new System.Drawing.Size(140, 20);
            this.txtFilter.TabIndex = 1;
            this.txtFilter.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Filter_KeyDown);
            // 
            // pckFilter
            // 
            this.pckFilter.Location = new System.Drawing.Point(87, 3);
            this.pckFilter.Name = "pckFilter";
            this.pckFilter.Size = new System.Drawing.Size(141, 20);
            this.pckFilter.TabIndex = 0;
            this.pckFilter.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Filter_KeyDown);
            // 
            // rolls
            // 
            this.rolls.ContextMenuStrip = this.treeMenu;
            this.rolls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rolls.Location = new System.Drawing.Point(0, 0);
            this.rolls.Name = "rolls";
            this.rolls.Size = new System.Drawing.Size(230, 349);
            this.rolls.TabIndex = 5;
            this.rolls.BeforeSelect += new System.Windows.Forms.TreeViewCancelEventHandler(this.rolls_BeforeSelect);
            this.rolls.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.rolls_AfterSelect);
            this.rolls.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.rolls_NodeMouseClick);
            // 
            // treeMenu
            // 
            this.treeMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.развернутьToolStripMenuItem,
            this.свернутьToolStripMenuItem,
            this.удалитьToolStripMenuItem,
            this.toolStripMenuItem3,
            this.копироватьToolStripMenuItem,
            this.извлечьToolStripMenuItem,
            this.создатьСравнениеToolStripMenuItem,
            this.toolStripMenuItem1,
            this.копироватьПутьToolStripMenuItem});
            this.treeMenu.Name = "treeMenu";
            this.treeMenu.Size = new System.Drawing.Size(214, 170);
            // 
            // развернутьToolStripMenuItem
            // 
            this.развернутьToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("развернутьToolStripMenuItem.Image")));
            this.развернутьToolStripMenuItem.Name = "развернутьToolStripMenuItem";
            this.развернутьToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.развернутьToolStripMenuItem.Text = "Развернуть";
            this.развернутьToolStripMenuItem.Click += new System.EventHandler(this.развернутьToolStripMenuItem_Click);
            // 
            // свернутьToolStripMenuItem
            // 
            this.свернутьToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("свернутьToolStripMenuItem.Image")));
            this.свернутьToolStripMenuItem.Name = "свернутьToolStripMenuItem";
            this.свернутьToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.свернутьToolStripMenuItem.Text = "Свернуть";
            this.свернутьToolStripMenuItem.Click += new System.EventHandler(this.свернутьToolStripMenuItem_Click);
            // 
            // удалитьToolStripMenuItem
            // 
            this.удалитьToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("удалитьToolStripMenuItem.Image")));
            this.удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
            this.удалитьToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.удалитьToolStripMenuItem.Text = "Удалить";
            this.удалитьToolStripMenuItem.Click += new System.EventHandler(this.удалитьToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(210, 6);
            // 
            // копироватьToolStripMenuItem
            // 
            this.копироватьToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("копироватьToolStripMenuItem.Image")));
            this.копироватьToolStripMenuItem.Name = "копироватьToolStripMenuItem";
            this.копироватьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.C)));
            this.копироватьToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.копироватьToolStripMenuItem.Text = "Копировать";
            this.копироватьToolStripMenuItem.Click += new System.EventHandler(this.копироватьToolStripMenuItem_Click);
            // 
            // извлечьToolStripMenuItem
            // 
            this.извлечьToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("извлечьToolStripMenuItem.Image")));
            this.извлечьToolStripMenuItem.Name = "извлечьToolStripMenuItem";
            this.извлечьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.извлечьToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.извлечьToolStripMenuItem.Text = "Извлечь";
            this.извлечьToolStripMenuItem.Click += new System.EventHandler(this.извлечьToolStripMenuItem_Click);
            // 
            // создатьСравнениеToolStripMenuItem
            // 
            this.создатьСравнениеToolStripMenuItem.Image = global::rollbase.Properties.Resources.compare;
            this.создатьСравнениеToolStripMenuItem.Name = "создатьСравнениеToolStripMenuItem";
            this.создатьСравнениеToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.создатьСравнениеToolStripMenuItem.Text = "Создать сравнение";
            this.создатьСравнениеToolStripMenuItem.Click += new System.EventHandler(this.создатьСравнениеToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(210, 6);
            // 
            // копироватьПутьToolStripMenuItem
            // 
            this.копироватьПутьToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("копироватьПутьToolStripMenuItem.Image")));
            this.копироватьПутьToolStripMenuItem.Name = "копироватьПутьToolStripMenuItem";
            this.копироватьПутьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.копироватьПутьToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.копироватьПутьToolStripMenuItem.Text = "Копировать путь";
            this.копироватьПутьToolStripMenuItem.Click += new System.EventHandler(this.копироватьПутьToolStripMenuItem_Click);
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.splitContainer4);
            this.splitContainer3.Panel1MinSize = 180;
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.readme);
            this.splitContainer3.Size = new System.Drawing.Size(550, 513);
            this.splitContainer3.SplitterDistance = 230;
            this.splitContainer3.TabIndex = 0;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.splitContainer6);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.splitContainer5);
            this.splitContainer4.Size = new System.Drawing.Size(230, 513);
            this.splitContainer4.SplitterDistance = 321;
            this.splitContainer4.TabIndex = 0;
            // 
            // splitContainer6
            // 
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer6.IsSplitterFixed = true;
            this.splitContainer6.Location = new System.Drawing.Point(0, 0);
            this.splitContainer6.Name = "splitContainer6";
            this.splitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.label2);
            this.splitContainer6.Panel1MinSize = 15;
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.pck);
            this.splitContainer6.Size = new System.Drawing.Size(230, 321);
            this.splitContainer6.SplitterDistance = 25;
            this.splitContainer6.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Location = new System.Drawing.Point(-1, 12);
            this.label2.MinimumSize = new System.Drawing.Size(53, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Список хранилища:";
            // 
            // pck
            // 
            this.pck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pck.Location = new System.Drawing.Point(0, 0);
            this.pck.Margin = new System.Windows.Forms.Padding(0);
            this.pck.Name = "pck";
            this.pck.ReadOnly = true;
            this.pck.Size = new System.Drawing.Size(230, 292);
            this.pck.TabIndex = 1;
            this.pck.Text = "";
            // 
            // splitContainer5
            // 
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer5.IsSplitterFixed = true;
            this.splitContainer5.Location = new System.Drawing.Point(0, 0);
            this.splitContainer5.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainer5.Name = "splitContainer5";
            this.splitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.label1);
            this.splitContainer5.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitContainer5.Panel1MinSize = 15;
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.files);
            this.splitContainer5.Size = new System.Drawing.Size(230, 188);
            this.splitContainer5.SplitterDistance = 25;
            this.splitContainer5.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(-1, 12);
            this.label1.MinimumSize = new System.Drawing.Size(53, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Файлы:";
            // 
            // files
            // 
            this.files.AccessibleName = "";
            this.files.Dock = System.Windows.Forms.DockStyle.Fill;
            this.files.Location = new System.Drawing.Point(0, 0);
            this.files.Name = "files";
            this.files.Size = new System.Drawing.Size(230, 159);
            this.files.TabIndex = 1;
            // 
            // readme
            // 
            this.readme.Dock = System.Windows.Forms.DockStyle.Fill;
            this.readme.Location = new System.Drawing.Point(0, 0);
            this.readme.Name = "readme";
            this.readme.ReadOnly = true;
            this.readme.Size = new System.Drawing.Size(316, 513);
            this.readme.TabIndex = 0;
            this.readme.Text = "";
            this.readme.WordWrap = false;
            this.readme.LinkClicked += new System.Windows.Forms.LinkClickedEventHandler(this.readme_LinkClicked);
            // 
            // openPCK
            // 
            this.openPCK.Filter = "Список хранилища|*.pck";
            this.openPCK.FileOk += new System.ComponentModel.CancelEventHandler(this.openPCK_FileOk);
            // 
            // Sync
            // 
            this.Sync.WorkerReportsProgress = true;
            this.Sync.WorkerSupportsCancellation = true;
            this.Sync.DoWork += new System.ComponentModel.DoWorkEventHandler(this.Sync_DoWork);
            this.Sync.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.Sync_ProgressChanged);
            this.Sync.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.Sync_RunWorkerCompleted);
            // 
            // NotifyIcon
            // 
            this.NotifyIcon.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.NotifyIcon.ContextMenuStrip = this.NotifyMenu;
            this.NotifyIcon.Text = "Менеджер накатов";
            this.NotifyIcon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.NotifyIcon_MouseDoubleClick);
            // 
            // NotifyMenu
            // 
            this.NotifyMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.востановитьToolStripMenuItem,
            this.toolStripMenuItem4,
            this.выходToolStripMenuItem});
            this.NotifyMenu.Name = "NotifyMenu";
            this.NotifyMenu.Size = new System.Drawing.Size(144, 54);
            // 
            // востановитьToolStripMenuItem
            // 
            this.востановитьToolStripMenuItem.Name = "востановитьToolStripMenuItem";
            this.востановитьToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.востановитьToolStripMenuItem.Text = "Востановить";
            this.востановитьToolStripMenuItem.Click += new System.EventHandler(this.востановитьToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(140, 6);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // Watcher
            // 
            this.Watcher.EnableRaisingEvents = true;
            this.Watcher.IncludeSubdirectories = true;
            this.Watcher.NotifyFilter = ((System.IO.NotifyFilters)(((((System.IO.NotifyFilters.FileName | System.IO.NotifyFilters.Attributes) 
            | System.IO.NotifyFilters.Size) 
            | System.IO.NotifyFilters.LastWrite) 
            | System.IO.NotifyFilters.CreationTime)));
            this.Watcher.SynchronizingObject = this;
            this.Watcher.Changed += new System.IO.FileSystemEventHandler(this.Watcher_Changed);
            this.Watcher.Created += new System.IO.FileSystemEventHandler(this.Watcher_Created);
            this.Watcher.Deleted += new System.IO.FileSystemEventHandler(this.Watcher_Changed);
            this.Watcher.Renamed += new System.IO.RenamedEventHandler(this.Watcher_Renamed);
            // 
            // Rollbase
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.toolStripContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "Rollbase";
            this.Text = "Менеджер накатов";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.mainMenu.ResumeLayout(false);
            this.mainMenu.PerformLayout();
            this.toolStripContainer1.BottomToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.BottomToolStripPanel.PerformLayout();
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.StatusSync.ResumeLayout(false);
            this.StatusSync.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel1.PerformLayout();
            this.splitContainer7.Panel2.ResumeLayout(false);
            this.splitContainer7.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).EndInit();
            this.splitContainer7.ResumeLayout(false);
            this.treeMenu.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.NotifyMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Watcher)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ToolStripMenuItem настройкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem синхронизацияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem зависимостиToolStripMenuItem;
        protected System.Windows.Forms.MenuStrip mainMenu;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.RichTextBox readme;
        private System.Windows.Forms.OpenFileDialog openPCK;
        private System.Windows.Forms.ContextMenuStrip treeMenu;
        private System.Windows.Forms.ToolStripMenuItem копироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem извлечьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem копироватьПутьToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem развернутьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem свернутьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        public System.Windows.Forms.ToolStripComboBox selBase;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox files;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox pck;
        private System.Windows.Forms.SplitContainer splitContainer7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox fileFilter;
        private System.Windows.Forms.TextBox txtFilter;
        private System.Windows.Forms.TextBox pckFilter;
        private System.Windows.Forms.Button Filter;
        private System.Windows.Forms.ToolStripMenuItem обновитьToolStripMenuItem;
        public System.Windows.Forms.TreeView rolls;
        private System.Windows.Forms.StatusStrip StatusSync;
        private System.Windows.Forms.ToolStripProgressBar ProgressSync;
        private System.Windows.Forms.ToolStripStatusLabel SyncProcent;
        private System.Windows.Forms.ToolStripStatusLabel CancelSync;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.TextBox rollFilter;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ToolStripMenuItem создатьСравнениеToolStripMenuItem;
        private System.ComponentModel.BackgroundWorker Sync;
        private System.Windows.Forms.CheckBox FilterCheck;
        private System.Windows.Forms.ToolStripMenuItem режимОжиданияToolStripMenuItem;
        private System.Windows.Forms.NotifyIcon NotifyIcon;
        private System.Windows.Forms.ContextMenuStrip NotifyMenu;
        private System.Windows.Forms.ToolStripMenuItem востановитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.IO.FileSystemWatcher Watcher;
    }
}

