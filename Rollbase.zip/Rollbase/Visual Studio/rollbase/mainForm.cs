﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
using Microsoft.Win32;
using System.Diagnostics;
using Word = Microsoft.Office.Interop.Word;
using System.Drawing;
using System.Text;
using rollbase.Properties;

namespace rollbase
{
    public partial class Rollbase : Form
    {
        public string connectionString(string sbase)
        {
            string result;
            RegistryKey RegKey = Registry.CurrentUser.OpenSubKey(rollbase.Properties.Resources.regKeyName + "\\" + sbase);
            result = "rollbase_" + sbase + ".mdb";
            if (RegKey != null)
            {
                result = (string)RegKey.GetValue("mdbPath", result);
                RegKey.Close();
            }

            result = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source =" + result + "; User ID = Admin; Password =;";

            return result;
        }

        public Rollbase()
        {
            InitializeComponent();
            NotifyIcon.Icon = Resources.Rollbase;
        }

        // Запуск гланой формы
        private void Form1_Load(object sender, EventArgs e)
        {
            RegistryKey RegKey;
            RegKey = Registry.CurrentUser.OpenSubKey(Resources.regKeyName);
            if (RegKey == null)
            {
                RegKey = Registry.CurrentUser.CreateSubKey(Resources.regKeyName);
                MessageBox.Show("Настройки программы не найдены!");
                settingsForm frm = new settingsForm(this);
                frm.ShowDialog(this);
            }

            string defBase = "RTL";
            selBase.Items.AddRange((string[])RegKey.GetValue("Bases", new string[] { defBase }));
            selBase.SelectedItem = (string)RegKey.GetValue("DefBase", defBase);
            bool SyncByRun = Convert.ToBoolean(RegKey.GetValue("SyncByRun", 0));
            RegKey.Close();
            TreeFilter_SelectedIndexChanged(sender, e);
            if (SyncByRun == true && синхронизацияToolStripMenuItem.Enabled == true && sender != настройкиToolStripMenuItem)
            {
                синхронизацияToolStripMenuItem_Click(sender, e);
            }
        }

        // Выбор Базы Данных
        private void selBase_SelectedIndexChanged(object sender, EventArgs e)
        {
            RegistryKey RegKey = Registry.CurrentUser.OpenSubKey(Resources.regKeyName, true);
            RegKey.SetValue("defBase", selBase.Text, RegistryValueKind.String);
            RegKey.Close();
            fillTreeRolls();
        }

        // Выбор режима работы(с фильтром или без фильтра)
        private void TreeFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (FilterCheck.Checked == true)
            {
                FilterCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
                FilterCheck.ForeColor = Color.Blue;
                splitContainer7.Panel2Collapsed = false;
                splitContainer7.Panel2.Show();
                splitContainer2.SplitterDistance = 160;
            }
            else
            {
                FilterCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
                FilterCheck.ForeColor = SystemColors.ControlText;
                splitContainer7.Panel2Collapsed = true;
                splitContainer7.Panel2.Hide();
                splitContainer2.SplitterDistance = 25;
                fillTreeRolls();
            }
        }

        //открыть последнюю ветку дерева
        private void lastExpand(TreeNode exNode)
        {
            exNode.Expand();
            if (exNode.Nodes.Count > 0)
            {
                lastExpand(exNode.Nodes[exNode.Nodes.Count - 1]);

            }
        }

        // Получение дерева накатов
        private void fillTreeRolls()
        {
            обновитьToolStripMenuItem.Tag = "old";
            rolls.Nodes.Clear();
            TreeView clone = getTreeNode(FilterCheck.Checked == true, selBase.SelectedItem.ToString());
            foreach (TreeNode node in clone.Nodes)
            {
                rolls.Nodes.Add((TreeNode)node.Clone());
            }
            if (rolls.Nodes.Count > 0)
            {
                lastExpand(rolls.Nodes[rolls.Nodes.Count - 1]);
            }
        }

        // Получение TMP - дерева накатов
        public TreeView getTreeNode(bool filter, string sbase)
        {
            //Дерево
            TreeView result = new TreeView();
            TreeNode rolik = result.TopNode;

            //База данных
            OleDbConnection conn;
            OleDbCommand cmd;
            string sql, sql_filter = "";
            OleDbDataReader reader;
            DateTime ddt, dt_now = (DateTime)DateTime.MinValue;

            try
            {
                conn = new OleDbConnection(connectionString(sbase));
                conn.Open();
                // Формируем запрос для получения дерева
                sql = "select valstr from Settings where name = 'rolldir'";
                cmd = new OleDbCommand(sql, conn);
                Watcher.Path = cmd.ExecuteScalar().ToString();

                sql = "select r.rolldate, r.filename, r.filedate, r.id from rolls as r where 1=1";
                if (filter)
                {
                    cmd.Parameters.Clear();
                    if (string.IsNullOrWhiteSpace(fileFilter.Text) && string.IsNullOrWhiteSpace(pckFilter.Text) && string.IsNullOrWhiteSpace(txtFilter.Text) && string.IsNullOrWhiteSpace(rollFilter.Text))
                    {
                    }
                    else
                    {
                        if (fileFilter.Text.Length > 0)
                        {
                            sql_filter += " and exists(select f.roll_id from files as f where  Ucase(f.filename) like @filefilter and f.roll_id = r.id)";
                            cmd.Parameters.AddWithValue("@filefilter",   "%" + fileFilter.Text.ToUpper().Replace("_", "[_]").Trim() + "%");
                        }
                        if (pckFilter.Text.Length > 0)
                        {
                            sql_filter += " and exists(select p.roll_id from pck as p where Ucase(p.str) like @pckfilter and p.roll_id = r.id)";
                            cmd.Parameters.AddWithValue("@pckFilter",    "%" + pckFilter.Text.ToUpper().Replace("_", "[_]").Trim() + "%");
                        }

                        if (txtFilter.Text.Length > 0)
                        {
                            sql_filter += " and exists(select rm.roll_id from readme as rm where Ucase(rm.str) like @txtfilter and rm.roll_id = r.id)";
                            cmd.Parameters.AddWithValue("@txtfilter",    "%" + txtFilter.Text.ToUpper().Replace("_", "[_]").Trim() + "%");
                        }
                        if (rollFilter.Text.Length > 0)
                        {
                            sql_filter = " and Ucase(filename) like @rollfilter";
                            cmd.Parameters.AddWithValue("@rollFilter",   "%" + rollFilter.Text.ToUpper().Replace("_", "[_]").Trim() + "%");
                        }
                    }
                }
                sql = sql + sql_filter + " order by r.rolldate asc, r.filedate asc;";
                cmd.CommandText = sql;

                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ddt = reader.GetDateTime(0);
                    if (rolik == null)
                    {
                        rolik = result.Nodes.Add(ddt.Year.ToString(), ddt.Year.ToString());
                        rolik = rolik.Nodes.Add(ddt.Month.ToString(), ddt.Month.ToString());
                        rolik = rolik.Nodes.Add(ddt.Day.ToString(), ddt.Day.ToString());
                    }
                    else if (ddt.CompareTo(dt_now) != 0)
                    {
                        rolik = rolik.Parent;
                        if (ddt.Year != dt_now.Year)
                        {
                            rolik = result.Nodes.Add(ddt.Year.ToString(), ddt.Year.ToString());
                            rolik = rolik.Nodes.Add(ddt.Month.ToString(), ddt.Month.ToString());
                        }
                        else if (ddt.Month != dt_now.Month)
                        {
                            rolik = rolik.Parent;
                            rolik = rolik.Nodes.Add(ddt.Month.ToString());
                        }
                        rolik = rolik.Nodes.Add(ddt.Day.ToString(), ddt.Day.ToString());
                    }
                    rolik = rolik.Nodes.Add(reader.GetString(1));
                    rolik.ToolTipText = reader.GetDateTime(2).ToString("dd.MM.yyyy hh:mm:ss");
                    rolik.Tag = reader.GetValue(3);
                    rolik = rolik.Parent;
                    dt_now = ddt;
                }
                reader.Close();
                cmd.Dispose();
                conn.Close();
                Watcher.EnableRaisingEvents = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection DataBase ! " + ex.Message);
            }
            result.SelectedNode = rolik;
            return result;
        }

        private void rolls_BeforeSelect(object sender, TreeViewCancelEventArgs e)
        {
            if(rolls.SelectedNode != null)
            {
                rolls.SelectedNode.ForeColor = Color.Black;
                rolls.SelectedNode.BackColor = Color.White;
            }
        }

        private void rolls_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (rolls.SelectedNode.Tag != null)
            {
                rolls.SelectedNode.ForeColor = Color.White;
                rolls.SelectedNode.BackColor = Color.Blue;
                OleDbConnection conn = new OleDbConnection(connectionString(selBase.SelectedItem.ToString()));
                OleDbCommand cmd = new OleDbCommand();
                string sql;
                OleDbDataReader reader;

                try
                {
                    cmd.Connection = conn;
                    conn.Open();

                    sql = "select str from readme where roll_id = @ID order by row_num asc";
                    cmd.CommandText = sql;
                    cmd.Parameters.Add("@ID", OleDbType.Integer);
                    cmd.Parameters["@ID"].Value = rolls.SelectedNode.Tag;

                    reader = cmd.ExecuteReader();
                    readme.Text = null;
                    while (reader.Read())
                    {
                        readme.Text += reader.GetString(0) + Environment.NewLine;
                    }
                    reader.Close();

                    sql = "select str from pck where roll_id = @ID order by row_num asc";
                    cmd.CommandText = sql;
                    reader = cmd.ExecuteReader();
                    pck.Text = null;
                    while (reader.Read())
                    {
                        pck.Text += reader.GetString(0) + Environment.NewLine;
                    }
                    reader.Close();

                    sql = "select filename from files where roll_id = @ID order by id asc";
                    cmd.CommandText = sql;
                    reader = cmd.ExecuteReader();
                    files.Items.Clear();
                    while (reader.Read())
                    {
                        files.Items.Add(reader.GetString(0));
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Can not open connection ! " + ex.Message);
                }
                finally
                {
                    cmd.Dispose();
                    conn.Close();
                }                
                if (FilterCheck.Checked == true)
                {
                    int go;
                    if (string.IsNullOrWhiteSpace(pckFilter.Text) == false)
                    {
                        go = pck.Text.IndexOf(pckFilter.Text.Trim(), StringComparison.InvariantCultureIgnoreCase);
                        if (go < 0)
                            return;
                        pck.Select(go, pckFilter.Text.Trim().Length);
                        pck.SelectionColor = Color.Red;
                    }
                    if (string.IsNullOrWhiteSpace(txtFilter.Text) == false)
                    {
                        go = readme.Text.IndexOf(txtFilter.Text.Trim(), StringComparison.InvariantCultureIgnoreCase);
                        if (go < 0)
                            return;
                        readme.Select(go, txtFilter.Text.Trim().Length);
                        readme.SelectionColor = Color.Red;
                    }
                }
            }
        }

        private void readme_LinkClicked(object sender, LinkClickedEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start(e.LinkText);
            }
            catch(Exception ex)
            {
                MessageBox.Show("readme_LinkClicked: " + ex.Message);
            }
        }

        private void openPCK_FileOk(object sender, CancelEventArgs e)
        {
            OleDbConnection conn = new OleDbConnection(connectionString(selBase.SelectedItem.ToString()));
            OleDbCommand cmd = new OleDbCommand();
            string pck_line, roll, roll_path;
            OleDbDataReader reader;
            int idx = 0;
            dependForm frm;

            cmd.Connection = conn;
            cmd.CommandText = "select TOP 1 cpm.fn, cpm.fp from (select r.filename as fn, r.filepath as fp,  r.id as idd, r.RollDate as dt from rolls as r, Pck as p where p.roll_id = r.id and p.str = @pck_line order by r.RollDate desc) as cpm";
            cmd.Parameters.Add("@pck_line", OleDbType.BSTR);
            conn.Open();

            StreamReader sr = new StreamReader(openPCK.FileName);

            frm = new dependForm();
            frm.listRolls.Text = null;

            string dirStart = Watcher.Path;

            while (sr.Peek() > -1)
            {
                pck_line = sr.ReadLine();
                if (pck_line.Length > 0)
                {
                    if (   pck_line.IndexOf("METH") >= 0
                        || pck_line.IndexOf("ATTR") >= 0
                        || pck_line.IndexOf("INDEX") >= 0
                        || pck_line.IndexOf("VIEW") >= 0)
                    {
                        cmd.Parameters["@pck_line"].Value = pck_line;
                        try
                        {
                            reader = cmd.ExecuteReader();
                            while (reader.Read())
                            {
                                roll = reader.GetString(0);
                                roll_path = reader.GetString(1);
                                roll = roll_path.Substring(dirStart.Length) + "\\" + roll;
                                if (Array.IndexOf(frm.listRolls.Lines, roll) < 0)
                                {
                                    frm.listRolls.Text += roll + Environment.NewLine;
                                    idx++;
                                }
                            }
                            reader.Close();
                        }
                        catch { }
                    }
                }
            }
            sr.Close();
            cmd.Dispose();
            conn.Close();
            if (idx > 0)
            {
                frm.Text = "Зависимости " + Path.GetFileName(openPCK.FileName);
                frm.ShowDialog(this);
            }
            else
            {
                MessageBox.Show("Зависимостей не найдено!");
            }
        }

        private void зависимостиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openPCK.ShowDialog(this);
        }

        private void настройкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            settingsForm frm = new settingsForm(this);
            if (frm.ShowDialog(this) == DialogResult.OK)
            {
                selBase.Items.Clear();
                Form1_Load(sender, e);
            }
            frm.Close();
        }

        private DateTime getDateRoll(FileInfo roll_file, string dirStart, string sbase)
        {
            RegistryKey RegKey = Registry.CurrentUser.OpenSubKey(Resources.regKeyName + "\\" + sbase);
            string fDate = "yyyy\\mm\\dd";
            DateTime result;
            int dateFolder_idx = 0;

            if (RegKey != null)
            {
                fDate = (string)RegKey.GetValue("dirF1", "*");
                dateFolder_idx++;
                if (fDate.CompareTo("*") == 0)
                {
                    dateFolder_idx++;
                    fDate = (string)RegKey.GetValue("dirF2", "*");
                    if (fDate.CompareTo("*") == 0)
                    {
                        dateFolder_idx++;
                        fDate = (string)RegKey.GetValue("dirF3", "*");
                    }
                }
                else
                {
                    dateFolder_idx --;
                    fDate = (string)RegKey.GetValue("dirF1", "*") + "\\"
                            + (string)RegKey.GetValue("dirF2", "*") + "\\"
                            + (string)RegKey.GetValue("dirF3", "*");
                }
                RegKey.Close();
            }
            string datestr = "0";
            if (dirStart.Length < roll_file.DirectoryName.Length)
            {
                datestr = roll_file.DirectoryName.Substring(dirStart.Length);
                while(dateFolder_idx > 0)
                {
                    datestr = datestr.Substring(datestr.IndexOf("\\") + 1);
                    dateFolder_idx--;
                }
                try
                {
                    datestr = datestr.Substring(0, fDate.Length);
                    result = DateTime.ParseExact(datestr, fDate, System.Globalization.CultureInfo.InvariantCulture);
                }
                catch(Exception)
                {
                    result = DateTime.MinValue;
                }

            }
            else
            {
                result = DateTime.Today;
            }
            return result;
        }

        private TreeNode find_rolik(TreeNode rolik, string search)
        {
            if (rolik == null)
                return null;

            foreach (TreeNode tn in rolik.Nodes)
            {
                //MessageBox.Show(tn.Text);
                if (tn.Text.CompareTo(search) == 0)
                {
                    return tn;
                }
            }

            return null;
        }

        private bool check_file(FileInfo roll_file, string dirStart, TreeView tv, string sbase)
        {
            DateTime checkDate = getDateRoll(roll_file, dirStart, sbase);
            TreeNode rolik = null;
            try
            {
                for (int i = 0; i < tv.GetNodeCount(false); i++)
                {
                    //MessageBox.Show(rolls.Nodes[i].Text);
                    if (tv.Nodes[i].Text.CompareTo(checkDate.Year.ToString()) == 0)
                    {
                        rolik = tv.Nodes[i];
                    }
                }
                if (rolik == null)
                {
                    return false;
                }

                //MessageBox.Show(checkDate.Year.ToString() + " - " + rolik.Nodes.Count);
                rolik = find_rolik(rolik, checkDate.Month.ToString());
                //MessageBox.Show(checkDate.Month.ToString() + " - " + rolik.Nodes.Count);
                rolik = find_rolik(rolik, checkDate.Day.ToString());
                //MessageBox.Show(checkDate.Day.ToString() + " - " + rolik.Nodes.Count);
                if (rolik == null)
                    return false;

                foreach (TreeNode roll in rolik.Nodes)
                    if (roll.Text.CompareTo(roll_file.Name) == 0 && roll.ToolTipText.CompareTo(roll_file.LastWriteTimeUtc.ToString("dd.MM.yyyy hh:mm:ss")) == 0)
                    {
                        //   if (roll.Name.CompareTo("20120201_other_infobesMessage.zip") == 0)
                        //MessageBox.Show(" +++ " + roll_file.Name + " = " + roll.Text + " | " + roll_file.LastWriteTimeUtc.ToString("dd.MM.yyyy hh:mm:ss") + " = " + roll.ToolTipText);
                        return true;
                    }
                /*else
                {
                    if (roll.Text.CompareTo(roll_file.Name) == 0)
                        if (roll.Name.CompareTo("20120201_other_infobesMessage.zip") == 0)
                            MessageBox.Show(roll_file.Name + " != " + roll.Text + " | " + roll_file.LastWriteTimeUtc.ToString("dd.MM.yyyy hh:mm:ss") + " != " + roll.ToolTipText);
                }
                /**/
                //MessageBox.Show(roll_file.Name + " | " + roll_file.LastWriteTimeUtc.ToString("dd.MM.yyyy hh:mm:ss"));
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("check_file: " + ex.Message);
                return false;
            }
        }

        private FileInfo[] get_file(string dirStart, FileInfo[] new_roll, TreeView tv, string sbase)
        {
            DirectoryInfo dir = new DirectoryInfo(dirStart);
            foreach (FileInfo file in dir.GetFiles("*", SearchOption.AllDirectories))
            {
                if (check_file(file, dirStart, tv, sbase) == false)
                {
                    //MessageBox.Show(file.FullName);
                    int cnt = new_roll.Length;
                    Array.Resize(ref new_roll, cnt + 1);
                    new_roll[cnt] = file;
                }
            }

            return new_roll;
        }

        private string get_file_inc(FileInfo roll)
        {
            BinaryReader instr = new BinaryReader(File.OpenRead(roll.FullName));
            byte[] data = instr.ReadBytes((int)instr.BaseStream.Length);
            instr.Close();
            // определяем BOM (EF BB BF)
            if (data.Length > 2 && data[0] == 0xef && data[1] == 0xbb && data[2] == 0xbf)
            {
                if (data.Length != 3)
                {
                    //MessageBox.Show(" utf8  = " + roll.FullName);
                    return Encoding.UTF8.GetString(data, 3, data.Length - 3);
                }
                else
                {
                    return "";
                }
            }

            int i = 0;
            while (i < data.Length - 1)
            {
                if (data[i] > 0x7f)
                { // не ANSI-символ
                    if ((data[i] >> 5) == 6)
                    {
                        if ((i > data.Length - 2) || ((data[i + 1] >> 6) != 2))
                        {
                            //MessageBox.Show("WIN-1251 3 = " + roll.FullName);
                            return Encoding.GetEncoding(1251).GetString(data);
                        }
                        i++;
                    }
                    else if ((data[i] >> 4) == 14)
                    {
                        if ((i > data.Length - 3) || ((data[i + 1] >> 6) != 2) || ((data[i + 2] >> 6) != 2))
                        {
                            //MessageBox.Show("WIN-1251 2 = " + roll.FullName);
                            //return Encoding.GetEncoding(20866).GetString(data);
                            return Encoding.GetEncoding(1251).GetString(data);
                        }
                        i += 2;
                    }
                    else if ((data[i] >> 3) == 30)
                    {
                        if ((i > data.Length - 4) || ((data[i + 1] >> 6) != 2) || ((data[i + 2] >> 6) != 2) || ((data[i + 3] >> 6) != 2))
                        {
                            //MessageBox.Show(" 1251 1 = " + roll.FullName);
                            return Encoding.GetEncoding(1251).GetString(data);
                        }
                        i += 3;
                    }
                    else
                    {
                        //MessageBox.Show("DOS866 = " + roll.FullName);
                        return Encoding.GetEncoding(866).GetString(data);
                    }
                }
                i++;
            }
            return Encoding.Default.GetString(data);
        }

        private void get_file_text(FileInfo roll, OleDbConnection conn, int roll_id, string tabName)
        {
            if (roll.Length > 102400)
                return;
            string[] separators = { "\r\n","\n","\r"};

            string sql_rolls = "INSERT into " + tabName + " (roll_id, row_num, str) values(@ID, @rownum, @str)";
            string sql_count = "SELECT count(1) + 1 from " + tabName + " where roll_id = @ID";
            string text = get_file_inc(roll);
            string[] lines = text.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            //StreamReader text = new StreamReader((System.IO.Stream)roll.OpenRead(), enc, false, 512);

            int line = 0, line_tmp = 0;
            OleDbCommand cmd = new OleDbCommand(sql_count, conn);
            cmd.Parameters.AddWithValue("@ID", roll_id);

            line = (int)cmd.ExecuteScalar();
            if (line < 1000)
            {
                cmd.CommandText = sql_rolls;
                cmd.Parameters.AddWithValue("@rownum", line);
                cmd.Parameters.AddWithValue("@str", "=========== " + roll.Name + " ===========");
                cmd.ExecuteNonQuery();

                string tmpline;
                for(int i = 0; i < lines.Length; i++)
                { 
                    if (String.IsNullOrEmpty(lines[i]))
                        lines[i] = " ";

                    while (lines[i].Length > 0)
                    {
                        if (lines[i].Length > 200)
                        {
                            tmpline = lines[i].Substring(0, 200);
                            lines[i] = lines[i].Substring(200);
                        }
                        else
                        {
                            tmpline = lines[i];
                            lines[i] = "";
                        }
                        line_tmp++;
                        cmd.Parameters["@rownum"].Value = line_tmp + line;
                        cmd.Parameters["@str"].Value = tmpline;
                        cmd.ExecuteNonQuery();
                        if (line_tmp > 100)
                            break;
                    }
                    if (line_tmp > 100)
                        break;
                }
            }
            cmd.Dispose();
        }

        private void get_doc_txt(FileInfo roll, OleDbConnection conn, int roll_id)
        {
            string sql_rolls = "INSERT into readme (roll_id, row_num, str) values(@ID, @rownum, @str)";
            string sql_count = "SELECT count(1) + 1 from  readme where roll_id = @ID";
            string tmpline, txt_line;
            string[] stringSeparators = new string[] { "\r\n" ,"\n\r", "\r", "\n"};

            int line = 0, line_tmp = 0;
            OleDbCommand cmd = new OleDbCommand(sql_count, conn);
            cmd.Parameters.AddWithValue("@ID", roll_id);
            line = (int)cmd.ExecuteScalar();

            if (line < 1000)
            {
                cmd.CommandText = sql_rolls;
                cmd.Parameters.AddWithValue("@rownum", line);
                cmd.Parameters.AddWithValue("@str", "=========== " + roll.Name + " ===========");
                cmd.ExecuteNonQuery();

                Word.Application word = new Word.Application();
                object miss = System.Reflection.Missing.Value;
                object readOnly = true;
                try
                {
                    Word.Document docs = word.Documents.Open(roll.FullName, ref miss, ref readOnly);
                    foreach (Word.Paragraph par in docs.Paragraphs)
                    {
                        line_tmp++;
                        string[] txt_lines = par.Range.Text.Split(stringSeparators, StringSplitOptions.None);

                        foreach (string txt_l in txt_lines)
                        {
                            txt_line = txt_l;
                            if (String.IsNullOrEmpty(txt_line))
                                continue;

                            while (txt_line.Length > 0)
                            {
                                if (txt_line.Length > 200)
                                {
                                    tmpline = txt_line.Substring(0, 200);
                                    txt_line = txt_line.Substring(200);
                                }
                                else
                                {
                                    tmpline = txt_line;
                                    txt_line = "";
                                }
                                line_tmp++;
                                cmd.Parameters["@rownum"].Value = line + line_tmp;
                                cmd.Parameters["@str"].Value = tmpline;
                                cmd.ExecuteNonQuery();
                                if (line_tmp > 100)
                                    break;
                            }
                            if (line_tmp > 100)
                                break;
                        }
                        if (line_tmp > 100)
                            break;
                    }
                    docs.Close();
                }
                catch (Exception)
                {

                }
                word.Quit();/**/
            }
            cmd.Dispose();
        }

        private void add_file2roll(FileInfo froll, OleDbConnection conn, int roll_id)
        {
            string sql_rolls = "INSERT into files (roll_id, filename) values(@ID, @filename)";
            OleDbCommand cmd = new OleDbCommand(sql_rolls, conn);
            cmd.Parameters.AddWithValue("@ID", roll_id);
            cmd.Parameters.AddWithValue("@filename", froll.Name);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
        }

        private DirectoryInfo exctract_roll(FileInfo roll, string archiver)
        {

            string dirTMP_name = roll.Directory + "\\" + Path.GetFileNameWithoutExtension(roll.FullName).Trim().Replace(".", "_");

            string arhivarius = "e -y -ibck \"" + roll.FullName + "\" \"" + dirTMP_name + "\\\"";

            ProcessStartInfo startInfo = new ProcessStartInfo(archiver);
            startInfo.WorkingDirectory = roll.Directory.FullName;
            startInfo.WindowStyle = ProcessWindowStyle.Maximized;
            startInfo.Arguments = arhivarius;

            try
            {
                // Start the process with the info we specified.
                using (Process exeProcess = Process.Start(startInfo))
                {
                    exeProcess.WaitForExit();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("exctract_roll: " + "Error Open" + ex.Message);
            }
            DirectoryInfo result = new DirectoryInfo(dirTMP_name);
            return result;
        }

        private void get_file_archive(FileInfo roll, OleDbConnection conn, int roll_id, string archiver)
        {
            DirectoryInfo dirTMP = exctract_roll(roll, archiver);

            if (dirTMP != null)
            {
                foreach (FileInfo file in dirTMP.GetFiles("*", SearchOption.AllDirectories))
                {
                    switch (file.Extension.ToLower())
                    {
                        case ".rar":
                            get_file_archive(file, conn, roll_id, archiver);
                            break;
                        case ".zip":
                            get_file_archive(file, conn, roll_id, archiver);
                            break;
                        case ".txt":
                            get_file_text(file, conn, roll_id, "readme");
                            break;
                        case ".me":
                            get_file_text(file, conn, roll_id, "readme");
                            break;
                        case ".doc":
                            get_doc_txt(file,conn, roll_id);
                            break;
                        case ".pck":
                            get_file_text(file, conn, roll_id, "pck");
                            break;
                        default:
                            break;
                    }
                    add_file2roll(file, conn, roll_id);
                }
                try
                {
                    dirTMP.Delete(true);
                }
                catch (UnauthorizedAccessException) { }
                catch (IOException) { }
            }
            else
            {
                //раз не удалось создать папку с архивом, то удаляем накат
                del_roll_id(conn, roll_id);
            }
            try
            {
                roll.Delete();
            }
            catch (UnauthorizedAccessException) { }
            catch (IOException) { }
        }

        private void del_roll_id(OleDbConnection conn, int roll_id)
        {
            string sql_files = "delete from files where roll_id = @ID";
            string sql_pck = "delete from pck where roll_id = @ID";
            string sql_readme = "delete from readme where roll_id = @ID";
            string sql_roll = "delete from rolls where id = @ID";
            OleDbCommand cmd = new OleDbCommand(sql_files, conn);
            cmd.Parameters.AddWithValue("@ID", roll_id);
            cmd.ExecuteNonQuery();

            cmd.CommandText = sql_pck;
            cmd.ExecuteNonQuery();
            cmd.CommandText = sql_readme;
            cmd.ExecuteNonQuery();
            cmd.CommandText = sql_roll;
            cmd.ExecuteNonQuery();

            cmd.Dispose();
        }
        // Синхронизация.Начало
            // Запуск
        private void синхронизацияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeView syncRoll = getTreeNode(false, selBase.SelectedItem.ToString()); // берем полное дерево (без фильтра) для синхронизации
            Object[] arguments = { syncRoll, selBase.SelectedItem };
            Watcher.EnableRaisingEvents = false;
            if (Sync.IsBusy)
            {
                MessageBox.Show("Синхронизация уже запущена. Дождитесь выполенния или отмените");
            }
            else
            {
                Sync.RunWorkerAsync(arguments);
            }
            CancelSync.Visible = true;
            синхронизацияToolStripMenuItem.Enabled = false;
        }
            // Во время синзронизации

        private bool addNewRolls(string sbase, FileInfo[] new_roll, bool autoSync)
        {
            // Часть 2 Создаем запись о накате
            OleDbConnection conn = new OleDbConnection(connectionString(sbase));
            string sql_rolls = "INSERT into rolls ( rolldate,   owner,  filepath,   filename,   filedate,   filesize,   state) " + 
                                            "values(@rolldate,  0,      @filepath,  @filename,  @filedate,  @filesize,  0);";
            string sql_newID = "Select @@Identity";
            string dirStart = Watcher.Path;
            OleDbCommand cmd = new OleDbCommand(sql_rolls, conn);
            int cnt = 0, newroll;
            int roll_id;
            conn.Open();

            cmd.Parameters.Add("@rolldate", OleDbType.Date);
            cmd.Parameters.Add("@filepath", OleDbType.VarChar);
            cmd.Parameters.Add("@filename", OleDbType.VarChar);
            cmd.Parameters.Add("@filedate", OleDbType.Date);
            cmd.Parameters.Add("@filesize", OleDbType.BigInt);

            // Выбарем архиватор
            RegistryKey RegKey = Registry.CurrentUser.OpenSubKey(Resources.regKeyName);
            string tmpPathRoll = (string)RegKey.GetValue("tmpRoll", Path.GetTempPath() + "tmpRollBase\\dbFill\\");
            DirectoryInfo tmpDir = Directory.CreateDirectory(tmpPathRoll);

            string archiver = (string)RegKey.GetValue("archiver", "winrar.exe");

            int prc = 0;
            //Считываем все накаты, которых нет в дереве
            foreach (FileInfo roll in new_roll)
            {
                if (dirStart.CompareTo(roll.Directory.ToString()) == 0)
                    continue;

                /*if (cnt >= 10)
                {
                    return;
                }/**/

                cmd.CommandText = sql_rolls;
                cmd.Parameters["@rolldate"].Value = (DateTime)getDateRoll(roll, dirStart, sbase);

                if ((DateTime)cmd.Parameters["@rolldate"].Value == DateTime.MinValue)
                {
                    continue;
                }

                cmd.Parameters["@filepath"].Value = roll.Directory.ToString();
                cmd.Parameters["@filename"].Value = roll.Name;
                cmd.Parameters["@filedate"].Value = roll.LastWriteTimeUtc;
                cmd.Parameters["@filesize"].Value = roll.Length;

                newroll = cmd.ExecuteNonQuery();
                cmd.CommandText = sql_newID;
                roll_id = (int)cmd.ExecuteScalar();
                //Созадем в базе Запись о накате
                //MessageBox.Show(roll_id.ToString()  +  " = " + roll  + " | " + roll.Extension.ToLower());
                cnt++;
                try
                {
                    FileInfo tmpFile = roll.CopyTo(tmpDir.FullName + "\\" + roll.Name, true);
                    if (roll == null)
                        continue;
                    switch (roll.Extension.ToLower())
                    {
                        case ".rar":
                            get_file_archive(tmpFile, conn, roll_id, archiver);
                            break;

                        case ".zip":
                            get_file_archive(tmpFile, conn, roll_id, archiver);
                            break;

                        case ".txt":
                            get_file_text(tmpFile, conn, roll_id, "readme");
                            add_file2roll(tmpFile, conn, roll_id);
                            break;

                        case ".me":
                            get_file_text(tmpFile, conn, roll_id, "readme");
                            add_file2roll(tmpFile, conn, roll_id);
                            break;

                        case ".pck":
                            get_file_text(tmpFile, conn, roll_id, "pck");
                            add_file2roll(tmpFile, conn, roll_id);
                            break;

                        case ".doc":
                            get_doc_txt(tmpFile, conn, roll_id);
                            add_file2roll(tmpFile, conn, roll_id);
                            break;

                        default:
                            Console.WriteLine("Default case");
                            break;
                    }
                    try
                    {
                        tmpFile.Delete();
                    }
                    catch (UnauthorizedAccessException) { }
                    catch (IOException) { }
                }
                catch (Exception)
                {
                    del_roll_id(conn, roll_id);
                }
                prc++;
                if(autoSync == false)
                {
                    Sync.ReportProgress(10 + 90 * prc / new_roll.Length);
                    if (Sync.CancellationPending)
                    {
                        return true;
                    }
                }
            }
            
            cmd.Dispose();
            conn.Close();
            return false;
        }
        public void Sync_DoWork(object sender, DoWorkEventArgs e)
        {
            //Входящие параметры
            Object[] arguments = e.Argument as Object[];
            TreeView tv = arguments[0] as TreeView;
            string sbase = arguments[1] as string;

            FileInfo[] new_roll = new FileInfo[0];

            RegistryKey RegKey;
            /*И так! начнем! надо
             * 1. найти файлы в папке и вложенных папках
             * 2. проверить был ли уже даный файл добавлен когда-то ранее???
             * 2. переместить данный файл в tmp папку
             * 3. разархиваровать его
             * 4. получить перечень файлов в архиве
             * 5. получить данные из PCK
             * 6. получить данные из readme
            /**/
            Sync.ReportProgress(5);
            if (Sync.CancellationPending)
            {
                e.Cancel = true;
                return;
            }

            RegKey = Registry.CurrentUser.OpenSubKey(Resources.regKeyName + "\\" + sbase);
            string dirStart = (string)RegKey.GetValue("rolldir", null);
            RegKey.Close();
            if (dirStart == null)
            {
                MessageBox.Show("В наcтройках не задана папка");
            }
            else
            {
                new_roll = get_file(dirStart, new_roll, tv, sbase);
            }
            Sync.ReportProgress(10);
            if (Sync.CancellationPending)
            {
                e.Cancel = true;
                return;
            }
            RegKey.Close();
            e.Cancel = addNewRolls(sbase, new_roll, false);
        }

            // После выолнения Синхронизации
        private void Sync_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            Watcher.EnableRaisingEvents = true;
            if (e.Cancelled)
                MessageBox.Show("Синхронизация отменена пользователем!");
            else
            {
                ProgressSync.Value = 100;
                SyncProcent.Text = "100%";
                MessageBox.Show("Синхронизация окончена!");
            }

            CancelSync.Visible = false;
            синхронизацияToolStripMenuItem.Enabled = true;
            fillTreeRolls();

            ProgressSync.Value = 0;
            SyncProcent.Text = null;
            
        }
        // Синхронизация. Конец
        private string getRollPath(string roll_id)
        {
            try
            {
                OleDbConnection conn = new OleDbConnection(connectionString(selBase.SelectedItem.ToString()));
                string sql_rolls = "select filepath & \"\\\" & filename from rolls where id = @id";
                OleDbCommand cmd = new OleDbCommand(sql_rolls, conn);
                cmd.Parameters.AddWithValue("@id", roll_id);
                string filepath;
                conn.Open();
                filepath = (string)cmd.ExecuteScalar();
                cmd.Dispose();
                conn.Close();
                return filepath;
            }
            catch
            {
                return null;
            }
        }

        private void копироватьПутьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (rolls.SelectedNode.Tag == null)
                return;

            Clipboard.SetText(getRollPath(rolls.SelectedNode.Tag.ToString()), TextDataFormat.Text);
        }

        private void deleteRoll(TreeNode tn)
        {
            if(tn.Nodes.Count > 0)
            {
                foreach(TreeNode child in tn.Nodes)
                {
                    deleteRoll(child);
                }
            }
            else if (tn.Tag != null)
            {
                OleDbConnection conn = new OleDbConnection(connectionString(selBase.SelectedItem.ToString()));
                conn.Open();
                del_roll_id(conn, (int)tn.Tag);
                conn.Close();
            }
        }
        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (rolls.SelectedNode.Nodes.Count == 0)
            {
                deleteRoll(rolls.SelectedNode);
            }
            else
            {
                if (MessageBox.Show("Вы уверены, что хотите удалить целую группу накатов?", "Внимание!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    foreach (TreeNode sellnoda in rolls.SelectedNode.Nodes)
                    {
                        deleteRoll(sellnoda);
                    }
                }
            }
            rolls.SelectedNode.Remove();
        }

        private FileInfo copy_roll(int roll_id, string sbase, string toPath)
        {
            OleDbConnection conn = new OleDbConnection(connectionString(sbase));
            string sql_rolls = "select filepath & \"\\\" & filename from rolls where id = @ID";
            OleDbCommand cmd = new OleDbCommand(sql_rolls, conn);
            cmd.Parameters.AddWithValue("@ID", roll_id);
            conn.Open();
            string filepath = (string)cmd.ExecuteScalar();
            cmd.Dispose();
            conn.Close();

            if (filepath == null)
                return null;

            FileInfo roll = new FileInfo(filepath);
            DirectoryInfo tmpDir = Directory.CreateDirectory(toPath);
            roll = roll.CopyTo(tmpDir.FullName + roll.Name, true);
            return roll;


        }

        private DirectoryInfo exctract_roll(int roll_id, string sbase, string toPath)
        {
            RegistryKey RegKey = Registry.CurrentUser.OpenSubKey(Resources.regKeyName);
            string archiver = (string)RegKey.GetValue("archiver", "winrar.exe");
            RegKey.Close();

            FileInfo roll = copy_roll((int)rolls.SelectedNode.Tag, selBase.SelectedItem.ToString(), toPath);
            DirectoryInfo result = exctract_roll(roll, archiver);
            roll.Delete();
            return result;
        }
    
        private void копироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (rolls.SelectedNode.Tag == null)
                return;
            RegistryKey RegKey = Registry.CurrentUser.OpenSubKey(Resources.regKeyName);
            string pathArc = (string)RegKey.GetValue("tmpCopy", Path.GetTempPath() + "tmpRollBase\\Copy\\");
            RegKey.Close();

            FileInfo roll = copy_roll((int)rolls.SelectedNode.Tag, selBase.SelectedItem.ToString(), pathArc);
            Process.Start("\"" + roll.Directory.FullName + "\"");
        }

        private void извлечьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (rolls.SelectedNode.Tag == null)
                return;

            RegistryKey RegKey = Registry.CurrentUser.OpenSubKey(Resources.regKeyName);
            string pathArc = (string)RegKey.GetValue("tmpArc", Path.GetTempPath() + "tmpRollBase\\Exctract\\");
            RegKey.Close();

            DirectoryInfo exctractDir = exctract_roll((int)rolls.SelectedNode.Tag, selBase.SelectedItem.ToString(), pathArc);
            Process.Start("\"" + exctractDir.FullName + "\"");
        }

        private void развернутьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rolls.SelectedNode.ExpandAll();
        }

        private void свернутьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rolls.SelectedNode.Collapse();
        }


        private void Sync_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            ProgressSync.Value = e.ProgressPercentage;
            SyncProcent.Text = e.ProgressPercentage + "%";
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            обновитьToolStripMenuItem.Image = Resources.refresh;
            fillTreeRolls();
        }

        private void CancelSync_Click(object sender, EventArgs e)
        {
            CancelSync.Visible = false;
            Sync.CancelAsync();
            MessageBox.Show("Запрос на остановку синхронизации отправлен");
        }

        private void rolls_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
                rolls.SelectedNode = e.Node;
        }

        private void Filter_Click(object sender, EventArgs e)
        {
            fillTreeRolls();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About fAbout = new About();
            fAbout.ShowDialog();
        }

        private void Filter_DragEnter(object sender, DragEventArgs e)
        {
            fillTreeRolls();
        }

        private void Filter_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                fillTreeRolls();
            }
        }

        private void create_config(DirectoryInfo dirMDB, string schemes, string usr)
        {
            
            if (dirMDB == null)
            {
                return;
            }

            RegistryKey RegKey = Registry.CurrentUser.OpenSubKey(Resources.regKeyName);
            string pathArc = (string)RegKey.GetValue("tmpComp", Path.GetTempPath() + "tmpRollBase\\Compare\\");
            RegKey.Close();

            string config = "<?xml version=\"1.0\" encoding=\"Windows-1251\"?>\n";
            config += "<configuration version = \"1\" "
                    + "server = \"" + schemes + "\" "
                    + "owner = \"IBS\" user = \"" + usr + "\" "
                    + "show-monitor=\"false\">\n\r";

            foreach (FileInfo file in dirMDB.GetFiles("*.mdb", SearchOption.AllDirectories))
            {
                config += "    <text id=\"" + file.Name + "\" "
                       + "storage-file=\"" + file.FullName + "\" "
                       + "text-mode=\"all\" "
                       + "folder-path=\"" + dirMDB.FullName + "\\Сравнение\" "
                       + "enabled=\"true\"/>\n\r";
            }

            config += "</configuration>";

            using (FileStream fs = File.Create(pathArc + "\\compare_config.xml"))
            {
                Byte[] info = Encoding.Default.GetBytes(config);
                fs.Write(info, 0, info.Length);
                fs.Close();
            }
        }

        private void создатьСравнениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (rolls.SelectedNode.Tag == null)
                return;

            compareForm CF = new compareForm();
            CF.roll2compare.Text = getRollPath(rolls.SelectedNode.Tag.ToString());
            //CF.pwdBase.Focus();
            if (CF.ShowDialog(this) == DialogResult.OK)
            {
                if (CF.picked.Checked)
                {
                    RegistryKey RegKey = Registry.CurrentUser.OpenSubKey(Resources.regKeyName);
                    string pathArc = (string)RegKey.GetValue("tmpComp", Path.GetTempPath() + "tmpRollBase\\Compare\\");
                    string Pick = (string)RegKey.GetValue("Pick", "Pick.exe");

                    DirectoryInfo exctractDir = exctract_roll((int)rolls.SelectedNode.Tag, selBase.SelectedItem.ToString(), pathArc);
                    create_config(exctractDir, CF.scheme2config, CF.usr2config);

                    ProcessStartInfo CompareProc = new ProcessStartInfo(Pick);
                    CompareProc.Arguments = "/cf " + "" + pathArc + "compare_config.xml /p " + CF.pwdBase.Text + " /lf " + pathArc + "test.log";
                    CompareProc.WorkingDirectory = pathArc;
                    CompareProc.WindowStyle = ProcessWindowStyle.Maximized;

                    try
                    {
                        // Start the process with the info we specified.
                        using (Process exeProcess = Process.Start(CompareProc))
                        {
                            exeProcess.WaitForExit();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("MergeProc: " + "Error Open" + ex.Message);
                    }

                    if (CF.merged.Checked)
                    {
                        string Merge = (string)RegKey.GetValue("Merge", "merge");
                        ProcessStartInfo MergeProc = new ProcessStartInfo(Merge);
                        int i = 0;
                        MergeProc.WorkingDirectory = pathArc;
                        MergeProc.WindowStyle = ProcessWindowStyle.Maximized;
                        foreach (DirectoryInfo startcmp in exctractDir.GetDirectories())
                        {
                            MergeProc.Arguments = "";
                            if (startcmp.Name.CompareTo("Сравнение") == 0)
                            {
                                foreach (DirectoryInfo cmp in startcmp.GetDirectories())
                                {
                                    i++;
                                    MergeProc.Arguments += " " + "\"" + cmp.FullName + "\"";
                                }
                            }
                        }
                        if (i > 3)
                        {
                            Process.Start(pathArc);
                        }
                        else
                        {
                            Process.Start(MergeProc);
                        }
                    }
                    RegKey.Close();
                }
            }
            CF.Close();
        }

        private void режимОжиданияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NotifyIcon.Visible = true;
            this.Hide();
        }

        private void востановитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NotifyIcon.Visible = false;
            if (обновитьToolStripMenuItem.Tag.ToString().CompareTo("new") == 0)
            {
                обновитьToolStripMenuItem_Click(sender, e);
            }
            this.Show();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void NotifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            востановитьToolStripMenuItem_Click(sender, e);
        }

        private void Watcher_Changed(object sender, FileSystemEventArgs e)
        {
            OleDbConnection conn = new OleDbConnection(connectionString(selBase.SelectedItem.ToString()));
            FileInfo roll = new FileInfo(e.FullPath);
            conn.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = conn;
            cmd.CommandText = "select id from rolls where FilePath & '\\' & FileName = @filename";
            cmd.Parameters.AddWithValue("@filename", e.FullPath);
            int roll_id;
            try
            {
                object result = cmd.ExecuteScalar();
                if (result == null)
                {
                    return;
                }
                roll_id = (int)result;
            }
            catch(Exception ex)
            {
                return;
            }
            if (roll_id == null)
            {
                return;
            }
            del_roll_id(conn, roll_id);
            cmd.Dispose();
            conn.Close();
            try
            {
                System.Threading.Thread.Sleep(5000);
                if (e.ChangeType == WatcherChangeTypes.Changed)
                {
                    FileInfo[] new_roll = new FileInfo[1];
                    new_roll[0] = new FileInfo(e.FullPath);
                    NotifyIcon.ShowBalloonTip(1000, "Обновление наката", e.Name, ToolTipIcon.Info);
                    addNewRolls(selBase.SelectedItem.ToString(), new_roll, true);
                }
                else
                {
                    NotifyIcon.ShowBalloonTip(1000, "Удалили накат", e.Name, ToolTipIcon.Info);
                }
                обновитьToolStripMenuItem.Image = Resources.refreshNEW;
                обновитьToolStripMenuItem.Tag = "new";
            }
            catch (Exception ex)
            {

            }
        }

        private void Watcher_Created(object sender, FileSystemEventArgs e)
        {
            System.Threading.Thread.Sleep(5000);
            FileInfo[] new_roll = new FileInfo[1];
            try
            {
                new_roll[0] = new FileInfo(e.FullPath);
                NotifyIcon.ShowBalloonTip(1000, "Новый накат", e.Name, ToolTipIcon.Info);
                addNewRolls(selBase.SelectedItem.ToString(), new_roll, true);
                обновитьToolStripMenuItem.Image = Resources.refreshNEW;
                обновитьToolStripMenuItem.Tag = "new";
            }
            catch (Exception ex)
            {
            }
        }

        private void Watcher_Renamed(object sender, RenamedEventArgs e)
        {
            OleDbConnection conn = new OleDbConnection(connectionString(selBase.SelectedItem.ToString()));
            FileInfo roll = new FileInfo(e.FullPath);
            conn.Open();
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = conn;
            cmd.CommandText = "update rolls set FileName = @rollname where FilePath & '\\' & FileName = @oldpath";
            cmd.Parameters.AddWithValue("@rollname", roll.Name);
            cmd.Parameters.AddWithValue("@oldpath", e.OldFullPath);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            conn.Close();
            обновитьToolStripMenuItem.Image = Resources.refreshNEW;
            обновитьToolStripMenuItem.Tag = "new";
        }
    }
}
